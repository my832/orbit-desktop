﻿param([ValidateSet('All','WiFi','Bluetooth')][string]$Kind='All',[ValidateSet('keep','On','Off')][string]$State='keep')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
[Windows.Devices.Radios.Radio,Windows.System.Devices,ContentType=WindowsRuntime] | Out-Null
$taskAwait=([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Wait-Radio($operation,[Type]$resultType){$task=$taskAwait.MakeGenericMethod($resultType).Invoke($null,@($operation));if(-not $task.Wait(10000)){throw 'Radio timeout'};return $task.Result}
$taskRadios=Wait-Radio ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])
if($State -ne 'keep'){
 $taskAccess=Wait-Radio ([Windows.Devices.Radios.Radio]::RequestAccessAsync()) ([Windows.Devices.Radios.RadioAccessStatus])
 if($taskAccess -ne 'Allowed'){throw 'Windows does not allow radio control'}
 $taskSelected=@($taskRadios | Where-Object { $_.Kind.ToString() -eq $Kind });if($taskSelected.Count -eq 0){throw 'No radio adapter'}
 foreach($taskRadio in $taskSelected){$taskResult=Wait-Radio ($taskRadio.SetStateAsync([Windows.Devices.Radios.RadioState]::$State)) ([Windows.Devices.Radios.RadioAccessStatus]);if($taskResult -ne 'Allowed'){throw 'Radio control denied'}}
}
@($taskRadios | ForEach-Object { @{kind=$_.Kind.ToString();state=$_.State.ToString();name=$_.Name} }) | ConvertTo-Json -Compress
