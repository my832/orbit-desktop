/* One coordinate space, in desktop DIPs, shared by input and placement. */
((root,factory)=>{const api=factory();if(typeof module==='object')module.exports=api;else root.OrbitGeometry=api;})(globalThis,()=>{
 const clamp=(v,min,max)=>min>max?(min+max)/2:Math.max(min,Math.min(v,max));
 function nearest(point,areas){return areas.reduce((best,a)=>{
  const distance=Math.hypot(point.x-clamp(point.x,a.x,a.x+a.width),point.y-clamp(point.y,a.y,a.y+a.height));
  return !best||distance<best.distance?{area:a,distance}:best;
 },null).area;}
 function release(point,size,areas){const a=nearest(point,areas),margin=Math.max(28,size/2+4);return {x:clamp(point.x,a.x+margin,a.x+a.width-margin),y:clamp(point.y,a.y+margin,a.y+a.height-margin)};}
 function desktop(areas){const x=Math.min(...areas.map(a=>a.x)),y=Math.min(...areas.map(a=>a.y));return {x,y,width:Math.max(...areas.map(a=>a.x+a.width))-x,height:Math.max(...areas.map(a=>a.y+a.height))-y};}
 return {clamp,nearest,release,desktop};
});
