$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot
$taskCompiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$taskTarget=Join-Path $taskRoot 'app\native\OrbitBridge.exe'
New-Item -ItemType Directory -Force (Split-Path $taskTarget) | Out-Null
$taskSources=Get-ChildItem -LiteralPath (Join-Path $taskRoot 'native') -Filter '*.cs' -File | ForEach-Object FullName
& $taskCompiler /nologo /target:exe /platform:x64 /optimize+ ("/out:"+$taskTarget) /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:System.Management.dll $taskSources
if($LASTEXITCODE -ne 0){throw 'Native bridge compilation failed'}
