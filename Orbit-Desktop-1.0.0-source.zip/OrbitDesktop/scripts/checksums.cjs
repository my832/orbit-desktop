const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
(async()=>{
 const dir=path.join(__dirname,'..','dist'),lines=[];
 for(const name of fs.readdirSync(dir).filter(n=>/\.(exe|zip)$/.test(n)).sort()){
  const hash=crypto.createHash('sha256');for await(const chunk of fs.createReadStream(path.join(dir,name)))hash.update(chunk);
  lines.push(`${hash.digest('hex')}  ${name}`);
 }
 fs.writeFileSync(path.join(dir,'SHA256SUMS.txt'),lines.join('\n')+'\n');console.log(`Wrote ${lines.length} SHA-256 checksums.`);
})().catch(e=>{console.error(e);process.exit(1)});
