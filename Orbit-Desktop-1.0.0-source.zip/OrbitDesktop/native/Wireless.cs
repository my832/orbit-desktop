﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;

static class Wireless {
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct IFACE{public Guid id;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=256)]public string name;public int state;}
 [StructLayout(LayoutKind.Sequential)]struct SSID{public uint length;[MarshalAs(UnmanagedType.ByValArray,SizeConst=32)]public byte[] bytes;}
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct NETWORK{[MarshalAs(UnmanagedType.ByValTStr,SizeConst=256)]public string profile;public SSID ssid;public int bss;public uint count;public int connectable;public uint reason,phyCount;[MarshalAs(UnmanagedType.ByValArray,SizeConst=8)]public uint[] phys;public int morePhy;public uint signal;public int secure,auth,cipher;public uint flags,reserved;}
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct CONNECTION{public int mode;[MarshalAs(UnmanagedType.LPWStr)]public string profile;public IntPtr ssid,bssids;public int bss;public uint flags;}
 static IntPtr Open(){uint version;IntPtr handle;uint r=WlanOpenHandle(2,IntPtr.Zero,out version,out handle);if(r!=0)throw new Exception("Wi-Fi 接口不可用");return handle;}
 public static object List(bool scan){IntPtr handle=Open(),interfaces=IntPtr.Zero;try{if(WlanEnumInterfaces(handle,IntPtr.Zero,out interfaces)!=0)throw new Exception("无法读取无线网卡");var result=new List<object>();int count=Marshal.ReadInt32(interfaces),size=Marshal.SizeOf(typeof(IFACE));for(int i=0;i<count;i++){var a=(IFACE)Marshal.PtrToStructure(IntPtr.Add(interfaces,8+i*size),typeof(IFACE));if(scan){WlanScan(handle,ref a.id,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero);System.Threading.Thread.Sleep(600);}IntPtr networks;uint code=WlanGetAvailableNetworkList(handle,ref a.id,0,IntPtr.Zero,out networks);if(code!=0)continue;try{int n=Marshal.ReadInt32(networks),ns=Marshal.SizeOf(typeof(NETWORK));for(int j=0;j<n;j++){var d=(NETWORK)Marshal.PtrToStructure(IntPtr.Add(networks,8+j*ns),typeof(NETWORK));int length=Math.Min(32,(int)d.ssid.length);if(length==0)continue;string name=Encoding.UTF8.GetString(d.ssid.bytes,0,length),hex=BitConverter.ToString(d.ssid.bytes,0,length).Replace("-","");result.Add(new{adapter=a.id.ToString(),name=name,hex=hex,profile=d.profile,signal=d.signal,secure=d.secure!=0,auth=d.auth,cipher=d.cipher,connected=(d.flags&1)!=0,known=!String.IsNullOrEmpty(d.profile),connectable=d.connectable!=0});}}finally{WlanFreeMemory(networks);}}return result;}finally{if(interfaces!=IntPtr.Zero)WlanFreeMemory(interfaces);WlanCloseHandle(handle,IntPtr.Zero);}}
 public static object Connect(string adapter,string name,string hex,string profile,bool secure,int auth,int cipher,string password){
  Guid id=new Guid(adapter);IntPtr h=Open();try{if(String.IsNullOrEmpty(profile)){
   if(hex.Length<2||hex.Length>64||hex.Length%2!=0)throw new Exception("无效的网络名称");for(int i=0;i<hex.Length;i++)if(!Uri.IsHexDigit(hex[i]))throw new Exception("无效的网络名称");
   string authentication="open",encryption="none";if(secure){if(auth==7){authentication="WPA2PSK";encryption="AES";}else if(auth==4){authentication="WPAPSK";encryption=cipher==2?"TKIP":"AES";}else if(auth==9){authentication="WPA3SAE";encryption="AES";}else throw new Exception("此网络需要已有的企业网络配置");if(password.Length<(auth==9?1:8)||password.Length>63)throw new Exception("请检查 Wi-Fi 密码长度");}
   profile="Orbit-"+name;string key=secure?"<sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>"+SecurityElement.Escape(password)+"</keyMaterial></sharedKey>":"";
   string xml="<?xml version=\"1.0\"?><WLANProfile xmlns=\"http://www.microsoft.com/networking/WLAN/profile/v1\"><name>"+SecurityElement.Escape(profile)+"</name><SSIDConfig><SSID><hex>"+hex+"</hex><name>"+SecurityElement.Escape(name)+"</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>manual</connectionMode><MSM><security><authEncryption><authentication>"+authentication+"</authentication><encryption>"+encryption+"</encryption><useOneX>false</useOneX></authEncryption>"+key+"</security></MSM></WLANProfile>";
   uint reason;if(WlanSetProfile(h,ref id,2,xml,null,true,IntPtr.Zero,out reason)!=0)throw new Exception("Windows 未接受网络配置");
  }var c=new CONNECTION{mode=0,profile=profile,bss=1};uint result=WlanConnect(h,ref id,ref c,IntPtr.Zero);if(result!=0)throw new Exception("无法发起 Wi-Fi 连接");return true;}finally{WlanCloseHandle(h,IntPtr.Zero);}
 }
 public static object Disconnect(string adapter){IntPtr h=Open();try{Guid id=new Guid(adapter);if(WlanDisconnect(h,ref id,IntPtr.Zero)!=0)throw new Exception("无法断开 Wi-Fi");return true;}finally{WlanCloseHandle(h,IntPtr.Zero);}}
 [DllImport("wlanapi.dll")]static extern uint WlanOpenHandle(uint version,IntPtr reserved,out uint negotiated,out IntPtr handle);
 [DllImport("wlanapi.dll")]static extern uint WlanCloseHandle(IntPtr handle,IntPtr reserved);
 [DllImport("wlanapi.dll")]static extern uint WlanEnumInterfaces(IntPtr h,IntPtr reserved,out IntPtr list);
 [DllImport("wlanapi.dll")]static extern uint WlanGetAvailableNetworkList(IntPtr h,ref Guid id,uint flags,IntPtr reserved,out IntPtr list);
 [DllImport("wlanapi.dll")]static extern uint WlanScan(IntPtr h,ref Guid id,IntPtr ssid,IntPtr ies,IntPtr reserved);
 [DllImport("wlanapi.dll")]static extern void WlanFreeMemory(IntPtr memory);
 [DllImport("wlanapi.dll",CharSet=CharSet.Unicode)]static extern uint WlanSetProfile(IntPtr h,ref Guid id,uint flags,string xml,string security,[MarshalAs(UnmanagedType.Bool)]bool overwrite,IntPtr reserved,out uint reason);
 [DllImport("wlanapi.dll")]static extern uint WlanConnect(IntPtr h,ref Guid id,ref CONNECTION c,IntPtr reserved);
 [DllImport("wlanapi.dll")]static extern uint WlanDisconnect(IntPtr h,ref Guid id,IntPtr reserved);
}
