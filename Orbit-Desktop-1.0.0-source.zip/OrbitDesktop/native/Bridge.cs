﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using Microsoft.Win32;
using OrbitBall;

static class Bridge {
 static JavaScriptSerializer json=new JavaScriptSerializer();
 static string configPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OrbitDesktop\\settings.json");
 static Dictionary<string,object> cfg;
 [STAThread]static void Main(){try{SetProcessDpiAwarenessContext(new IntPtr(-4));}catch{}Console.InputEncoding=new UTF8Encoding(false);Console.OutputEncoding=new UTF8Encoding(false);cfg=Load();SystemStatus.Start();string line;while((line=Console.ReadLine())!=null){object id=null;try{var req=json.Deserialize<Dictionary<string,object>>(line);id=req["id"];var args=req.ContainsKey("args")?req["args"] as Dictionary<string,object>:new Dictionary<string,object>();var result=Handle((string)req["method"],args??new Dictionary<string,object>());Console.WriteLine(json.Serialize(new {id=id,ok=true,result=result}));}catch(Exception ex){Console.WriteLine(json.Serialize(new {id=id,ok=false,error=ex.Message}));}}}
 static string Str(Dictionary<string,object> a,string key,string fallback=""){return a.ContainsKey(key)?Convert.ToString(a[key]):fallback;}
 static bool Bool(Dictionary<string,object> a,string key){return a.ContainsKey(key)&&Convert.ToBoolean(a[key]);}
 static string Detect(string key){
  string executable=key=="Edge"?"msedge.exe":"WeChat.exe";
  foreach(var hive in new[]{Registry.CurrentUser,Registry.LocalMachine})foreach(string file in key=="Edge"?new[]{"msedge.exe"}:new[]{"WeChat.exe","Weixin.exe"})
   try{using(var k=hive.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\App Paths\"+file)){string p=k==null?null:k.GetValue("") as string;if(!String.IsNullOrEmpty(p)&&File.Exists(p.Trim('"')))return p.Trim('"');}}catch{}
  foreach(string basePath in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)})
   foreach(string relative in key=="Edge"?new[]{@"Microsoft\Edge\Application\msedge.exe"}:new[]{@"Tencent\WeChat\WeChat.exe",@"Tencent\Weixin\Weixin.exe",@"Programs\Tencent\WeChat\WeChat.exe",@"Programs\Tencent\Weixin\Weixin.exe"}){string p=Path.Combine(basePath,relative);if(File.Exists(p))return p;}
  return "";
 }
 static Dictionary<string,object> Load(){
  var v=new Dictionary<string,object>();try{var saved=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(configPath));foreach(string key in new[]{"WeChat","Edge"})if(saved.ContainsKey(key))v[key]=saved[key];}catch{}
  foreach(string key in new[]{"WeChat","Edge"})if(!v.ContainsKey(key)||String.IsNullOrWhiteSpace(Convert.ToString(v[key]))||!File.Exists(Convert.ToString(v[key])))v[key]=Detect(key);
  return v;
 }
 static object Handle(string method,Dictionary<string,object> a){switch(method){
  case "wifi.list":return Wireless.List(Bool(a,"scan"));
  case "wifi.connect":return Wireless.Connect(Str(a,"adapter"),Str(a,"name"),Str(a,"hex"),Str(a,"profile"),Bool(a,"secure"),Convert.ToInt32(a["auth"]),Convert.ToInt32(a["cipher"]),Str(a,"password"));
  case "wifi.disconnect":return Wireless.Disconnect(Str(a,"adapter"));
  case "bluetooth.list":return BluetoothDevices.List(Bool(a,"discover"));
  case "bluetooth.pair":return BluetoothDevices.Pair(Str(a,"id"));
  case "bluetooth.status":return BluetoothDevices.Status();
  case "bluetooth.reply":return BluetoothDevices.Reply(Bool(a,"accept"),Str(a,"pin"));
  case "bluetooth.remove":return BluetoothDevices.Remove(Str(a,"id"));
  case "bluetooth.connection":return BluetoothDevices.Connection(Str(a,"id"),Bool(a,"enabled"));
  case "system.night":return NightLight.Read();
  case "system.night.set":return NightLight.Set(a.ContainsKey("enabled")?(bool?)Bool(a,"enabled"):null);
  case "system.status":return SystemStatus.Read();
  case "system.brightness":return SystemStatus.SetBrightness(Convert.ToInt32(a["value"]));
  case "system.plans":return SystemStatus.PowerPlans();
  case "system.plan":return SystemStatus.SetPlan(Str(a,"id"));
  case "system.foreground":return SystemStatus.Foreground(Convert.ToInt32(a["pid"]));
  case "config.get":return cfg;
  case "config.save":foreach(var key in new[]{"WeChat","Edge"})if(a.ContainsKey(key))cfg[key]=a[key];Directory.CreateDirectory(Path.GetDirectoryName(configPath));File.WriteAllText(configPath,json.Serialize(cfg),Encoding.UTF8);return true;
  case "audio.list":{int flow=Convert.ToInt32(a["flow"]);string current="";try{current=Audio.Default(flow);}catch{}var list=new List<object>();foreach(var d in Audio.Devices(flow)){try{list.Add(new{id=d.Id,name=d.Name,level=Audio.Level(d.Id),muted=Audio.Muted(d.Id),isDefault=d.Id==current});}catch{}}return list.ToArray();}
  case "audio.level":Audio.SetLevel(Str(a,"id"),Convert.ToSingle(a["value"]));return true;
  case "audio.mute":Audio.Mute(Str(a,"id"),Bool(a,"value"));return true;
  case "audio.default":Audio.SetDefault(Str(a,"id"));return true;
  case "audio.step":{string id=Audio.Default(0);Audio.SetLevel(id,Audio.Level(id)+Convert.ToSingle(a["delta"]));return Audio.Level(id);}
  case "app.action":return AppAction(Str(a,"app"),Str(a,"action"));
  case "launch":Launch(Str(a,"target"),Str(a,"arguments"));return true;
  case "icon":{string key=Str(a,"key");string target=cfg.ContainsKey(key)?Convert.ToString(cfg[key]):"";if(!File.Exists(target))return null;using(var icon=Icon.ExtractAssociatedIcon(target))using(var bitmap=icon.ToBitmap())using(var m=new MemoryStream()){bitmap.Save(m,System.Drawing.Imaging.ImageFormat.Png);return "data:image/png;base64,"+Convert.ToBase64String(m.ToArray());}}
  case "processes":{var result=new List<object>();foreach(string name in new[]{"WeChat","Edge"}){var ps=Processes(name);long bytes=0;foreach(var p in ps){try{bytes+=p.WorkingSet64;}catch{}}result.Add(new{name=name,count=ps.Length,memory=Math.Round(bytes/1048576.0)});foreach(var p in ps)p.Dispose();}return result;}
  case "startup.get":using(var k=Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run"))return k!=null&&k.GetValue("OrbitDesktop")!=null;
  case "startup.set":using(var k=Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run")){if(Bool(a,"value"))k.SetValue("OrbitDesktop","\""+Str(a,"path")+"\" --background");else k.DeleteValue("OrbitDesktop",false);}return true;
  case "lock":return LockWorkStation();
  case "window.above":{IntPtr front=new IntPtr(Int64.Parse(Str(a,"front"))),back=new IntPtr(Int64.Parse(Str(a,"back")));IntPtr h=GetTopWindow(IntPtr.Zero);for(int i=0;i<4096&&h!=IntPtr.Zero;i++,h=GetWindow(h,2)){if(h==front)return true;if(h==back)return false;}return false;}
  case "window.hit":{IntPtr target=new IntPtr(Int64.Parse(Str(a,"window")));var point=new POINT{X=Convert.ToInt32(a["x"]),Y=Convert.ToInt32(a["y"])};var actual=WindowFromPoint(point);return actual==target||GetAncestor(actual,2)==target;}
  case "window.region":{IntPtr target=new IntPtr(Int64.Parse(Str(a,"window"))),region=CreateRectRgn(0,0,0,0);try{RECT bounds;GetWindowRect(target,out bounds);int kind=GetWindowRgn(target,region);return new{inside=kind==0||PtInRegion(region,Convert.ToInt32(a["x"])-bounds.Left,Convert.ToInt32(a["y"])-bounds.Top),ignoresInput=(GetWindowLong(target,-20)&0x20)!=0,visible=IsWindowVisible(target),regionKind=kind};}finally{DeleteObject(region);}}
  default:throw new ArgumentException("Unsupported operation");
 }}
 static Process[] Processes(string name){if(name!="WeChat"&&name!="Edge")throw new ArgumentException("未知应用");return (name=="Edge"?new[]{"msedge"}:new[]{"WeChat","Weixin"}).SelectMany(n=>Process.GetProcessesByName(n)).ToArray();}
 static object AppAction(string name,string action){
  if(!new[]{"show","minimize","top","close"}.Contains(action))throw new ArgumentException("未知操作");
  var ps=Processes(name);try{var window=ps.FirstOrDefault(p=>p.MainWindowHandle!=IntPtr.Zero);
   if(action=="show"){if(window!=null){ShowWindow(window.MainWindowHandle,9);SetForegroundWindow(window.MainWindowHandle);}else{string target=Convert.ToString(cfg[name]);if(!File.Exists(target)){target=Detect(name);cfg[name]=target;}if(String.IsNullOrEmpty(target))throw new ArgumentException("未找到程序，请点击选择程序指定安装位置");Launch(target,"");}}
   else if(window==null)return false;else if(action=="minimize")ShowWindow(window.MainWindowHandle,6);else if(action=="top"){bool top=(GetWindowLong(window.MainWindowHandle,-20)&8)!=0;SetWindowPos(window.MainWindowHandle,new IntPtr(top?-2:-1),0,0,0,0,0x13);}else if(action=="close")window.CloseMainWindow();return true;
  }finally{foreach(var p in ps)p.Dispose();}
 }
 static void Launch(string target,string arguments){if(String.IsNullOrEmpty(target))throw new ArgumentException("请先选择程序");if(target.StartsWith("shell:"))Process.Start(new ProcessStartInfo("explorer.exe",target){UseShellExecute=true});else Process.Start(new ProcessStartInfo(target,arguments){UseShellExecute=true,WorkingDirectory=File.Exists(target)?Path.GetDirectoryName(target):""});}
 [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr h,int n);
 [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")]static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int z,uint flags);
 [DllImport("user32.dll")]static extern bool LockWorkStation();
 [DllImport("user32.dll")]static extern IntPtr GetTopWindow(IntPtr h);
 [DllImport("user32.dll")]static extern IntPtr GetWindow(IntPtr h,uint command);
 [StructLayout(LayoutKind.Sequential)]struct POINT{public int X,Y;}
 [DllImport("user32.dll")]static extern IntPtr WindowFromPoint(POINT p);
 [DllImport("user32.dll")]static extern bool SetProcessDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")]static extern IntPtr GetAncestor(IntPtr h,uint flags);
 [StructLayout(LayoutKind.Sequential)]struct RECT{public int Left,Top,Right,Bottom;}
 [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr h,out RECT rect);
 [DllImport("user32.dll")]static extern int GetWindowRgn(IntPtr h,IntPtr region);
 [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr h);
 [DllImport("gdi32.dll")]static extern IntPtr CreateRectRgn(int left,int top,int right,int bottom);
 [DllImport("gdi32.dll")]static extern bool PtInRegion(IntPtr region,int x,int y);
 [DllImport("gdi32.dll")]static extern bool DeleteObject(IntPtr obj);
}
