﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using Microsoft.Win32;

// CloudStore CompactBinary v1. Preserve unmodified fields at every envelope level.
static class NightLight {
 const string Root=@"Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\DefaultAccount\Current\default$windows.data.bluelightreduction.";
 static string Key(string kind){return Root+kind+@"\windows.data.bluelightreduction."+kind;}
 internal sealed class Field { public int Id,Type; public byte[] Value; }
 internal sealed class Doc {
  public List<Field> Fields=new List<Field>();
  public Field Get(int id){return Fields.FirstOrDefault(f=>f.Id==id);}
  public void Put(int id,int type,byte[] value){Fields.RemoveAll(f=>f.Id==id);Fields.Add(new Field{Id=id,Type=type,Value=value});}
  public byte[] Pack(bool header=false){using(var m=new MemoryStream()){if(header)m.Write(new byte[]{67,66,1,0},0,4);foreach(var f in Fields.OrderBy(f=>f.Id)){if(f.Id<6)m.WriteByte((byte)(f.Type|(f.Id<<5)));else if(f.Id<=255){m.WriteByte((byte)(f.Type|192));m.WriteByte((byte)f.Id);}else{m.WriteByte((byte)(f.Type|224));m.WriteByte((byte)f.Id);m.WriteByte((byte)(f.Id>>8));}m.Write(f.Value,0,f.Value.Length);}m.WriteByte(0);return m.ToArray();}}
 }
 internal static byte[] Var(ulong v){var b=new List<byte>();do{byte a=(byte)(v&127);v>>=7;b.Add((byte)(a|(v>0?128:0)));}while(v>0);return b.ToArray();}
 static ulong Number(byte[] b){int p=0;return ReadVar(b,ref p);}
 static ulong ReadVar(byte[] b,ref int p){ulong n=0;for(int shift=0;shift<70;shift+=7){if(p>=b.Length)throw new FormatException();byte x=b[p++];if(shift==63&&x>1)throw new FormatException();n|=(ulong)(x&127)<<shift;if(x<128)return n;}throw new FormatException();}
 static void Skip(byte[] b,ref int p,int t,int depth){if(depth>16)throw new FormatException();switch(t){case 2:case 3:case 14:p++;break;case 4:case 5:case 6:case 15:case 16:case 17:ReadVar(b,ref p);break;case 7:p+=4;break;case 8:p+=8;break;case 9:case 18:{int n=checked((int)ReadVar(b,ref p));p+=t==18?checked(n*2):n;break;}case 10:Parse(b,ref p,depth+1);break;case 11:case 12:{int element=b[p++];int n=checked((int)ReadVar(b,ref p));if(n>4096)throw new FormatException();for(int i=0;i<n;i++)Skip(b,ref p,element,depth+1);break;}case 13:{int key=b[p++],value=b[p++],n=checked((int)ReadVar(b,ref p));if(n>4096)throw new FormatException();for(int i=0;i<n;i++){Skip(b,ref p,key,depth+1);Skip(b,ref p,value,depth+1);}break;}default:throw new FormatException();}if(p>b.Length)throw new FormatException();}
 static Doc Parse(byte[] b,ref int p,int depth){var doc=new Doc();while(p<b.Length){byte h=b[p++];int type=h&31;if(type==0)return doc;if(type==1)continue;int id=h>>5;if(id==6)id=b[p++];else if(id==7){id=b[p++]|(b[p++]<<8);}int start=p;Skip(b,ref p,type,depth);if(doc.Get(id)!=null)throw new FormatException();doc.Fields.Add(new Field{Id=id,Type=type,Value=b.Skip(start).Take(p-start).ToArray()});}throw new FormatException();}
 internal static Doc Decode(byte[] b,bool header=false){int p=0;if(header){if(b.Length<5||b[0]!=67||b[1]!=66||b[2]!=1||b[3]!=0)throw new FormatException();p=4;}var doc=Parse(b,ref p,0);if(p!=b.Length)throw new FormatException();return doc;}
 static Field Require(Doc d,int id,int type){var f=d.Get(id);if(f==null||f.Type!=type)throw new FormatException();return f;}
 internal sealed class Store {
  Doc outer,container,wrapper; internal Doc Body; string kind;
  public Store(string name,byte[] bytes){kind=name;outer=Decode(bytes,true);container=Decode(Require(outer,1,10).Value);wrapper=Decode(Require(container,1,10).Value);var blob=Require(wrapper,1,11).Value;int p=1;if(blob[0]!=14)throw new FormatException();int n=checked((int)ReadVar(blob,ref p));if(n!=blob.Length-p)throw new FormatException();Body=Decode(blob.Skip(p).ToArray(),true);}
  public byte[] Pack(){var body=Body.Pack(true);wrapper.Put(1,11,new byte[]{14}.Concat(Var((ulong)body.Length)).Concat(body).ToArray());container.Put(1,10,wrapper.Pack());ulong old=Number(Require(container,0,6).Value),now=(ulong)(DateTime.UtcNow-new DateTime(1970,1,1)).TotalSeconds;container.Put(0,6,Var(Math.Max(now,checked(old+2))));outer.Put(1,10,container.Pack());return outer.Pack(true);}

 }
 static Store Load(string kind){using(var key=Registry.CurrentUser.OpenSubKey(Key(kind))){var b=key==null?null:key.GetValue("Data") as byte[];if(b==null)throw new InvalidOperationException("系统夜间模式不可用");return new Store(kind,b);}}
 static bool Enabled(Store state){var f=state.Body.Get(0);if(f==null)return false;if(f.Type!=16||Number(f.Value)!=0)throw new FormatException();return true;}
 internal static object Read(){try{var state=Load("bluelightreductionstate");var settings=Load("settings");var usable=state.Body.Get(30);bool supported=usable==null||(usable.Type==2&&usable.Value[0]!=0);var temp=settings.Body.Get(40);int? strength=null;if(temp!=null){if(temp.Type!=15)throw new FormatException();ulong z=Number(temp.Value);int k=(int)((z>>1)^(ulong)-(long)(z&1));strength=Math.Max(0,Math.Min(100,(int)Math.Round((6500-k)*100.0/5300)));}return new{supported=supported,enabled=Enabled(state),strength=strength};}catch{return new{supported=false,enabled=false,strength=(int?)null};}}
 // Invoke the same settings handler used by Windows. Registry writes alone do not
 // reliably apply a display transform on newer Windows builds.
 [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
 [DllImport("SettingsHandlers_Display.dll",ExactSpelling=true)]
 static extern int GetSetting(IntPtr id,out IntPtr item);
 [DllImport("combase.dll")]static extern int RoInitialize(uint kind);
 [DllImport("combase.dll")]static extern void RoUninitialize();
 [DllImport("combase.dll",CharSet=CharSet.Unicode)]static extern int WindowsCreateString(string text,int length,out IntPtr value);
 [DllImport("combase.dll")]static extern int WindowsDeleteString(IntPtr value);
 [StructLayout(LayoutKind.Sequential)]struct ActionRect {public float X,Y,Width,Height;}
 [UnmanagedFunctionPointer(CallingConvention.StdCall)]delegate int SettingInvoke(IntPtr self,IntPtr window,ActionRect rect);
 static void Pump(int milliseconds){var clock=Stopwatch.StartNew();while(clock.ElapsedMilliseconds<milliseconds){System.Windows.Forms.Application.DoEvents();Thread.Sleep(10);}}
 static void Check(int hr){if(hr<0)Marshal.ThrowExceptionForHR(hr);}
 internal static object Set(bool? enabled){
  if(!enabled.HasValue)throw new ArgumentException("请指定夜间模式开关状态");
  var state=Load("bluelightreductionstate");var usable=state.Body.Get(30);
  if(usable!=null&&(usable.Type!=2||usable.Value[0]==0))throw new InvalidOperationException("系统夜间模式不可用");
  int init=RoInitialize(0);IntPtr name=IntPtr.Zero,item=IntPtr.Zero;
  try{
   Check(init);
   string id="SystemSettings_Display_BlueLight_ManualToggle"+(enabled.Value?"On":"Off");
   Check(WindowsCreateString(id,id.Length,out name));Check(GetSetting(name,out item));
   if(item==IntPtr.Zero)throw new InvalidOperationException("无法加载系统夜间模式组件");
   // The handler initializes asynchronously on its STA dispatcher. Keep pumping
   // its messages before invoking, and while Windows commits the result.
   Pump(3000);
   var address=Marshal.ReadIntPtr(Marshal.ReadIntPtr(item),17*IntPtr.Size);
   var invoke=(SettingInvoke)Marshal.GetDelegateForFunctionPointer(address,typeof(SettingInvoke));
   Check(invoke(item,IntPtr.Zero,new ActionRect()));
   Pump(500);
   var clock=Stopwatch.StartNew();
   while(Enabled(Load("bluelightreductionstate"))!=enabled.Value){
    if(clock.ElapsedMilliseconds>5000)throw new InvalidOperationException("Windows 未应用夜间模式，请重试");
    Pump(50);
   }
   return Read();
  }catch(COMException ex){throw new InvalidOperationException("系统夜间模式切换失败（"+ex.ErrorCode.ToString("X8")+"）");}
  finally{if(item!=IntPtr.Zero)Marshal.Release(item);if(name!=IntPtr.Zero)WindowsDeleteString(name);if(init>=0)RoUninitialize();}
 }
}
