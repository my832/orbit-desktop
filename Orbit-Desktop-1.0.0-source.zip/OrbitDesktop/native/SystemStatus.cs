﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Threading;

static class SystemStatus {
 static readonly object gate=new object();static Dictionary<string,object> current=new Dictionary<string,object>();
 static ulong lastIdle,lastKernel,lastUser;static long lastIn,lastOut;static DateTime lastAt=DateTime.UtcNow;
 static double? gpu=null,watts=null;static bool external=true;static int? brightness=null;static PerformanceCounter[] gpuCounters=new PerformanceCounter[0];
 public static void Start(){var worker=new Thread(Loop);worker.IsBackground=true;worker.Start();}
 public static object Read(){lock(gate)return new Dictionary<string,object>(current);}
 static void Loop(){int tick=0;for(;;){try{Sample(tick++);}catch{}Thread.Sleep(1000);}}
 static void Sample(int tick){
  ulong idle,kernel,user;GetSystemTimes(out idle,out kernel,out user);ulong total=kernel-lastKernel+user-lastUser;double cpu=lastKernel==0?0:100*(1-(double)(idle-lastIdle)/Math.Max(1,total));lastIdle=idle;lastKernel=kernel;lastUser=user;
  var memory=new MEMORYSTATUSEX();memory.Length=(uint)Marshal.SizeOf(memory);GlobalMemoryStatusEx(ref memory);
  long received=0,sent=0;foreach(var n in NetworkInterface.GetAllNetworkInterfaces())if(n.OperationalStatus==OperationalStatus.Up&&(n.NetworkInterfaceType==NetworkInterfaceType.Wireless80211||n.NetworkInterfaceType==NetworkInterfaceType.Ethernet)){var s=n.GetIPStatistics();received+=s.BytesReceived;sent+=s.BytesSent;}
  var at=DateTime.UtcNow;double elapsed=Math.Max(.01,(at-lastAt).TotalSeconds),download=lastIn==0?0:Math.Max(0,(received-lastIn)/elapsed),upload=lastOut==0?0:Math.Max(0,(sent-lastOut)/elapsed);lastIn=received;lastOut=sent;lastAt=at;
  if(tick%4==0){
   SYSTEM_POWER_STATUS power;GetSystemPowerStatus(out power);external=power.ACLineStatus==1;watts=null;
   try{using(var q=new ManagementObjectSearcher("root\\wmi","SELECT DischargeRate,Discharging FROM BatteryStatus"))foreach(ManagementObject b in q.Get()){if(Convert.ToBoolean(b["Discharging"])){double rate=Convert.ToDouble(b["DischargeRate"]);if(rate>0&&rate<1000000)watts=(watts??0)+rate/1000;}}}catch{}
   try{using(var q=new ManagementObjectSearcher("root\\wmi","SELECT CurrentBrightness FROM WmiMonitorBrightness"))foreach(ManagementObject b in q.Get()){brightness=Convert.ToInt32(b["CurrentBrightness"]);break;}}catch{}
  }
  if(tick%12==0)try{foreach(var counter in gpuCounters)counter.Dispose();var category=new PerformanceCounterCategory("GPU Engine");gpuCounters=category.GetInstanceNames().Select(n=>{try{var c=new PerformanceCounter("GPU Engine","Utilization Percentage",n,true);c.NextValue();return c;}catch{return null;}}).Where(c=>c!=null).Take(1600).ToArray();}catch{gpuCounters=new PerformanceCounter[0];}
  try{var engines=new Dictionary<string,double>();foreach(var counter in gpuCounters){try{string n=counter.InstanceName;int i=n.IndexOf("_luid_");string key=i>=0?n.Substring(i):n;double v=Math.Max(0,counter.NextValue());engines[key]=(engines.ContainsKey(key)?engines[key]:0)+v;}catch{}}gpu=engines.Count==0?(double?)null:Math.Min(100,engines.Values.Max());}catch{gpu=null;}
  lock(gate)current=new Dictionary<string,object>{{"cpu",Math.Round(Math.Max(0,Math.Min(100,cpu)),1)},{"gpu",gpu},{"memory",memory.Load},{"usedGB",Math.Round((memory.Total-memory.Available)/1073741824.0,1)},{"totalGB",Math.Round(memory.Total/1073741824.0,1)},{"download",download},{"upload",upload},{"watts",watts},{"external",external},{"brightness",brightness},{"time",at.ToString("o")}};
 }
 public static object SetBrightness(int value){value=Math.Max(0,Math.Min(100,value));bool done=false;using(var q=new ManagementObjectSearcher("root\\wmi","SELECT * FROM WmiMonitorBrightnessMethods"))foreach(ManagementObject m in q.Get()){m.InvokeMethod("WmiSetBrightness",new object[]{(uint)0,(byte)value});done=true;}if(!done)throw new Exception("此显示器不支持亮度调节");brightness=value;return true;}
 public static object PowerPlans(){var list=new List<object>();uint index=0;IntPtr activePtr;Guid active=Guid.Empty;if(PowerGetActiveScheme(IntPtr.Zero,out activePtr)==0){active=(Guid)Marshal.PtrToStructure(activePtr,typeof(Guid));LocalFree(activePtr);}for(;;){uint size=16;IntPtr buffer=Marshal.AllocHGlobal(16);try{if(PowerEnumerate(IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,16,index++,buffer,ref size)!=0)break;Guid id=(Guid)Marshal.PtrToStructure(buffer,typeof(Guid));uint bytes=0;PowerReadFriendlyName(IntPtr.Zero,ref id,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,ref bytes);IntPtr name=Marshal.AllocHGlobal((int)bytes);try{PowerReadFriendlyName(IntPtr.Zero,ref id,IntPtr.Zero,IntPtr.Zero,name,ref bytes);list.Add(new{id=id.ToString(),name=Marshal.PtrToStringUni(name),active=id==active});}finally{Marshal.FreeHGlobal(name);}}finally{Marshal.FreeHGlobal(buffer);}}return list;}
 public static object SetPlan(string value){Guid id=new Guid(value);if(PowerSetActiveScheme(IntPtr.Zero,ref id)!=0)throw new Exception("无法切换电源模式");return true;}
 public static object Foreground(int ownPid){IntPtr h=GetForegroundWindow();RECT r;GetWindowRect(h,out r);uint pid;GetWindowThreadProcessId(h,out pid);var cls=new System.Text.StringBuilder(256);GetClassName(h,cls,cls.Capacity);long style=GetWindowLong(h,-16);return new{own=pid==(uint)ownPid,dialog=cls.ToString()=="#32770",caption=(style&0x00C00000)!=0,maximized=IsZoomed(h),x=r.Left,y=r.Top,width=r.Right-r.Left,height=r.Bottom-r.Top};}
 [StructLayout(LayoutKind.Sequential)]struct MEMORYSTATUSEX{public uint Length,Load;public ulong Total,Available,PageTotal,PageAvailable,VirtualTotal,VirtualAvailable,Extended;}
 [StructLayout(LayoutKind.Sequential)]struct SYSTEM_POWER_STATUS{public byte ACLineStatus,BatteryFlag,BatteryLifePercent,SystemStatusFlag;public int BatteryLifeTime,BatteryFullLifeTime;}
 [StructLayout(LayoutKind.Sequential)]struct RECT{public int Left,Top,Right,Bottom;}
 [DllImport("kernel32.dll")]static extern bool GetSystemTimes(out ulong idle,out ulong kernel,out ulong user);
 [DllImport("kernel32.dll")]static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX data);
 [DllImport("kernel32.dll")]static extern bool GetSystemPowerStatus(out SYSTEM_POWER_STATUS status);
 [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr p);
 [DllImport("powrprof.dll")]static extern uint PowerGetActiveScheme(IntPtr root,out IntPtr active);
 [DllImport("powrprof.dll")]static extern uint PowerSetActiveScheme(IntPtr root,ref Guid scheme);
 [DllImport("powrprof.dll")]static extern uint PowerEnumerate(IntPtr root,IntPtr scheme,IntPtr sub,uint access,uint index,IntPtr buffer,ref uint size);
 [DllImport("powrprof.dll")]static extern uint PowerReadFriendlyName(IntPtr root,ref Guid scheme,IntPtr sub,IntPtr setting,IntPtr buffer,ref uint size);
 [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")]static extern bool IsZoomed(IntPtr h);
 [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr h,out RECT rect);
 [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr h,System.Text.StringBuilder name,int size);
 [DllImport("user32.dll")]static extern int GetWindowLong(IntPtr h,int index);
}
