const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, screen, globalShortcut, dialog } = require('electron');
const {spawn}=require('child_process');
const fs=require('fs'),path=require('path'),readline=require('readline');
const geometry=require('./geometry.js');
const qaVisualOnly=process.argv.includes('--qa-visual');
const qaDragOnly=process.argv.includes('--qa-drag'),qa=qaVisualOnly||qaDragOnly||process.argv.includes('--qa'),inputTest=process.argv.includes('--input-test');
app.setName('Orbit Desktop');
app.setAppUserModelId('io.github.orbitdesktop.app');
app.commandLine.appendSwitch('force-renderer-accessibility');
app.setPath('userData',path.join(app.getPath('appData'),'OrbitDesktop'));
let win,tray,bridge,pending=new Map(),seq=0,config={},mode='closed',timer,moveTimer,drag=null,blackWindows=[],blackKeys=[],blackRestoreVisible=true,quitting=false,smartTimer,smartHidden=false,smartBusy=false;
let recent=[],started=Date.now(),dragRestore=null,gesture=null,modeRevision=0,hostRevision=0,lastGestureToken=0;
if(qa)app.setPath('userData',path.join(app.getPath('appData'),'OrbitDesktop-QA'));
const qaCaptureDir=path.join(app.getPath('userData'),'captures');if(qa)fs.mkdirSync(qaCaptureDir,{recursive:true});
const prefPath=path.join(app.getPath('userData'),'desktop.json');
let prefs={surface:"classic",layout:"honeycomb",palette:"original",reveal:"smooth",size:48,follow:true,animate:true,top:true,anchor:null,shortcuts:[],topMode:"smart",theme:"system",glass:.2,opacity:.66,highlight:.12,monitorPinned:false,monitorCompact:false,monitorFont:16,autoExpressions:true};
try{prefs={...prefs,...JSON.parse(fs.readFileSync(prefPath,'utf8'))};}catch{}
function save(){fs.mkdirSync(path.dirname(prefPath),{recursive:true});fs.writeFileSync(prefPath,JSON.stringify(prefs,null,2));}
function log(text){recent.unshift({time:new Date().toLocaleTimeString(),text});recent=recent.slice(0,30);}
function rpc(method,args={}){return new Promise((resolve,reject)=>{if(!bridge||bridge.killed)return reject(new Error('系统接口尚未就绪'));const id=++seq;const timeout=setTimeout(()=>{pending.delete(id);reject(new Error('系统操作超时'));},12000);pending.set(id,{resolve,reject,timeout});bridge.stdin.write(JSON.stringify({id,method,args})+'\n');});}
function startBridge(){bridge=spawn(path.join(__dirname.replace('app.asar','app.asar.unpacked'),'native','OrbitBridge.exe'),[],{windowsHide:true,stdio:['pipe','pipe','ignore']});const lines=readline.createInterface({input:bridge.stdout});lines.on('line',line=>{try{const v=JSON.parse(line),p=pending.get(v.id);if(!p)return;pending.delete(v.id);clearTimeout(p.timeout);v.ok?p.resolve(v.result):p.reject(new Error(v.error));}catch{}});bridge.on('exit',()=>{for(const p of pending.values()){clearTimeout(p.timeout);p.reject(new Error('系统接口已退出'));}pending.clear();});bridge.on('error',err=>log(err.message));}
function send(data){if(win&&!win.isDestroyed())win.webContents.send('state',data);}
function fitCenter(anchor,nextMode,area){let center={...anchor};const clamp=(v,min,max)=>min>max?(min+max)/2:Math.max(min,Math.min(v,max));if(nextMode==='menu'){center.x=clamp(center.x,area.x+160,area.x+area.width-160);center.y=clamp(center.y,area.y+192,area.y+area.height-316);}else if(prefs.monitorPinned){center.x=clamp(center.x,area.x+150,area.x+area.width-150);center.y=clamp(center.y,area.y+96,area.y+area.height-28);}return center;}
// The HWND is created once over the desktop. Only the scene moves, on the GPU.
function desktopBounds(){return geometry.desktop(screen.getAllDisplays().map(d=>d.bounds));}
function placement(anchor=prefs.anchor,animate=true){
 const area=screen.getDisplayNearestPoint(anchor).workArea,center=fitCenter(anchor,mode,area);
 return {kind:'placement',center,host:win.getBounds(),areas:screen.getAllDisplays().map(d=>d.workArea),animate,left:center.x>area.x+area.width/2,revision:hostRevision,token:lastGestureToken};
}
function place(anchor=prefs.anchor,animate=true){send(placement(anchor,animate));}
async function setMode(next){
 const revision=++modeRevision;
 if(gesture||dragRestore)await finishDrag();
 if(revision!==modeRevision||gesture)return;
 mode=next;place();send({kind:'mode',value:next});
 if(next==='closed')win.blur();else if(next==='menu'&&!blackWindows.length){win.show();win.focus();}
}
async function refreshDesktop(){
 const revision=++hostRevision,visible=win.isVisible();
 await finishDrag();if(revision!==hostRevision)return;
 win.hide();prefs.anchor=geometry.release(prefs.anchor,prefs.size,screen.getAllDisplays().map(d=>d.workArea));
 win.setBounds(desktopBounds(),false);save();place(prefs.anchor,false);
 // Rare topology changes get their own ready acknowledgement; gestures never resize.
 await win.webContents.executeJavaScript('window.orbitViewportReady()').catch(()=>{});
 if(revision===hostRevision&&visible&&!blackWindows.length)win.showInactive();
}
async function black(){
 if(blackWindows.length)return;
 if(gesture||dragRestore)await finishDrag();blackRestoreVisible=win.isVisible();clearInterval(moveTimer);drag=null;win.hide();
 for(const key of ['Escape','Space'])if(globalShortcut.register(key,restoreBlack))blackKeys.push(key);
 for(const d of screen.getAllDisplays()){
  const b=new BrowserWindow({x:d.bounds.x,y:d.bounds.y,width:d.bounds.width,height:d.bounds.height,frame:false,thickFrame:true,roundedCorners:false,hasShadow:false,backgroundColor:'#000000',alwaysOnTop:true,skipTaskbar:true,show:false,resizable:true,fullscreenable:true,fullscreen:true,webPreferences:{sandbox:true,preload:path.join(__dirname,'black-preload.cjs')}});
  blackWindows.push(b);b.setAlwaysOnTop(true,'screen-saver');b.setMenuBarVisibility(false);
  b.loadURL('data:text/html,<html style="background:%23000"><body style="margin:0;background:%23000"></body></html>');
  b.once('ready-to-show',()=>{if(!blackWindows.includes(b))return;b.show();b.setFullScreen(true);b.moveTop();b.focus();});
  b.on('closed',()=>{blackWindows=blackWindows.filter(v=>v!==b);if(!blackWindows.length)finishBlack();});
 }
 send({kind:'black',value:true});log('黑屏已开启');
}
function finishBlack(){
 for(const key of blackKeys)globalShortcut.unregister(key);blackKeys=[];
 if(win&&!win.isDestroyed()&&!quitting){win.setAlwaysOnTop(prefs.topMode!=='normal','floating');if(blackRestoreVisible)win.showInactive();send({kind:'black',value:false});}
}
function restoreBlack(){
 const windows=[...blackWindows];blackWindows=[];for(const b of windows)if(!b.isDestroyed())b.destroy();finishBlack();log('黑屏已关闭');
}
function validCenter(p){return p&&Number.isFinite(p.x)&&Number.isFinite(p.y);}
function armGesture(data){
 if(blackWindows.length||!Number.isSafeInteger(data?.token)||data.token<=0||!validCenter(data.center))return;
 if(data.token<=lastGestureToken)return;lastGestureToken=data.token;
 gesture={token:data.token,pointerId:data.pointerId};
}
function startDrag(data){
 if(!gesture||data?.token!==gesture.token||data.pointerId!==gesture.pointerId||!validCenter(data.center))return;
 drag={...gesture};prefs.anchor={...data.center};mode='closed';
 // The pointer is captured by Chromium. Expanding only the input region keeps
 // the orb visible anywhere on this stationary canvas, without another HWND.
 const b=win.getBounds();win.setShape([{x:0,y:0,width:b.width,height:b.height}]);
 send({kind:'mode',value:mode,token:drag.token});
}
function updateDrag(data){
 if(!drag||data?.token!==drag.token||data.pointerId!==drag.pointerId||!validCenter(data.center))return;
 prefs.anchor={...data.center};
}
function commitGesture(data){
 if(!gesture||data?.token!==gesture.token)return;
 if(drag&&validCenter(data.center))prefs.anchor=geometry.release(data.center,prefs.size,screen.getAllDisplays().map(d=>d.workArea));
 const token=gesture.token,wasDrag=!!drag;gesture=null;drag=null;
 if(wasDrag)save();
 send({kind:'gesture-finished',token,center:wasDrag?prefs.anchor:null});
}
async function finishDrag(){
 if(dragRestore)return dragRestore;
 if(!gesture)return;
 const token=gesture.token;
 dragRestore=(async()=>{
  const data=await win.webContents.executeJavaScript(`window.cancelOrbitGesture(${token})`).catch(()=>null);
  if(gesture?.token===token)commitGesture({token,center:validCenter(data?.center)?data.center:prefs.anchor});
 })();
 try{await dragRestore;}finally{dragRestore=null;}
}

async function touchCheck(){
 const original={...prefs.anchor},originalMode=mode,pause=ms=>new Promise(r=>setTimeout(r,ms)),result={};
 const host=win.getBounds(),area=screen.getDisplayNearestPoint(prefs.anchor).workArea;
 const sameHost=()=>{const b=win.getBounds();return ['x','y','width','height'].every(k=>b[k]===host[k]);};
 const js=code=>win.webContents.executeJavaScript(code);
 const idle=async()=>{await pause(60);return !gesture&&!drag&&!dragRestore&&await js("activePointer===null&&!dragging&&!sceneMotion&&getComputedStyle(ball).visibility==='visible'");};
 const visual=()=>js("centerOnDesktop()");
 const at=async p=>{await finishDrag();prefs.anchor={...p};mode='closed';place(prefs.anchor,false);send({kind:'mode',value:mode});await pause(60);};
 win.webContents.debugger.attach('1.3');
 const input=(type,points)=>win.webContents.debugger.sendCommand('Input.dispatchTouchEvent',{type,touchPoints:points.map(p=>({x:p.x-host.x,y:p.y-host.y,id:p.id||1,radiusX:5,radiusY:5,force:1}))});
 const near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)<2;
 let stationary=true;const delays=[];let captureIndex=0;
 const paintCheck=async()=>{
  await pause(20);const rect=await js("(()=>{const r=ball.getBoundingClientRect();return {left:r.left-8,top:r.top-8,right:r.right+8,bottom:r.bottom+8};})()"),image=await win.webContents.capturePage();
  if(captureIndex<4)fs.writeFileSync(path.join(qaCaptureDir,`qa-drag-frame-${captureIndex++}.png`),image.toPNG());
  const bitmap=image.resize({width:host.width,height:host.height}).toBitmap({scaleFactor:1});
  let white=0,stray=0;
  for(let y=0;y<host.height;y++)for(let x=0;x<host.width;x++){
   const i=(y*host.width+x)*4;
   if(bitmap[i+3]>200&&bitmap[i]>235&&bitmap[i+1]>235&&bitmap[i+2]>235){white++;if(x<rect.left||x>rect.right||y<rect.top||y>rect.bottom)stray++;}
  }
  return {white,stray,ok:white>100&&stray===0};
 };
 const passThrough=async()=>{
  const c=await visual(),handle=win.getNativeWindowHandle().readBigUInt64LE().toString();
  const orb=await rpc('window.region',{window:handle,...screen.dipToScreenPoint(c)});
  const gap=await rpc('window.region',{window:handle,...screen.dipToScreenPoint({x:area.x+8,y:area.y+8})});
  return orb.inside&&!orb.ignoresInput&&orb.visible&&!gap.inside;
 };
 try{
  const center={x:area.x+area.width/2,y:area.y+area.height/2};await at(center);win.moveTop();
  result.passthroughBefore=await passThrough();
  const start={...center},offset={x:7,y:-5},finger={x:start.x+offset.x,y:start.y+offset.y};
  await input('touchStart',[finger]);
  const targets=Array.from({length:32},(_,i)=>({x:finger.x+Math.sin((i+1)/6)*95,y:finger.y+20+(i+1)*2}));
  let follows=true;
  for(const [i,p]of targets.entries()){
   const begin=performance.now();await input('touchMove',[p]);const expected={x:p.x-offset.x,y:p.y-offset.y};
   let actual;do{actual=await visual();if(near(actual,expected))break;await pause(1);}while(performance.now()-begin<120);
   follows&&=near(actual,expected);delays.push(Math.round((performance.now()-begin)*10)/10);stationary&&=sameHost();
   if(i===10)result.paintDuringDrag=await paintCheck();
  }
  result.offsetPreserved=follows;result.touchDispatchToDOMMs=delays;
  const svg=await js("document.querySelector('#avatar svg').outerHTML");await pause(60);
  result.dragAnimationLive=svg!==await js("document.querySelector('#avatar svg').outerHTML");
  result.dragExpression=await js("OrbitCharacter.state==='dragging'");
  const last=targets.at(-1);await input('touchEnd',[]);
  result.releaseFollows=near(await visual(),{x:last.x-offset.x,y:last.y-offset.y});result.releaseIdle=await idle();
  result.paintAfterRelease=await paintCheck();result.passthroughAfter=await passThrough();
  result.saved=near(JSON.parse(fs.readFileSync(prefPath,'utf8')).anchor,prefs.anchor);
  // Immediate pickup, release and reversal: no sleeps between separate gestures.
  let rapid=true;
  for(let i=0;i<24;i++){
   const c=await visual(),end={x:c.x+(i%2?-9:9),y:c.y+(i%2?6:-6)};
   await input('touchStart',[c]);await input('touchMove',[end]);await input('touchEnd',[]);
   rapid&&=near(await visual(),end);stationary&&=sameHost();
  }
  result.rapid24=rapid&&await idle();
  // A completed gesture's messages must not change the next finger's state.
  const stale=await js('gestureToken'),c=await visual();await input('touchStart',[c]);await input('touchMove',[{x:c.x+16,y:c.y+12}]);
  const before=await visual();updateDrag({token:stale,pointerId:1,center:{x:0,y:0}});commitGesture({token:stale,center:{x:0,y:0}});
  send({kind:'gesture-finished',token:stale,center:{x:0,y:0}});await pause(20);
  result.staleMessagesIgnored=!!drag&&near(before,await visual());await input('touchEnd',[]);await idle();
  const multi=await visual();await input('touchStart',[multi]);await input('touchMove',[{x:multi.x+22,y:multi.y+11}]);
  const primary={x:multi.x+22,y:multi.y+11};await input('touchStart',[{...primary,id:1},{x:primary.x+35,y:primary.y+30,id:2}]);
  await input('touchMove',[{...primary,id:1},{x:primary.x+80,y:primary.y+60,id:2}]);
  result.secondFingerIgnored=!!drag&&near(primary,await visual());await input('touchCancel',[]);result.cancelClears=await idle();
  const lost=await visual();await input('touchStart',[lost]);await input('touchMove',[{x:lost.x+21,y:lost.y+9}]);
  await js('ball.releasePointerCapture(activePointer)');await input('touchMove',[{x:lost.x+23,y:lost.y+10}]);await pause(30);result.captureRecoversWithContact=await js('activePointer!==null&&ball.hasPointerCapture(activePointer)');await input('touchCancel',[]);result.lostCaptureClears=await idle();
  const blur=await visual();await input('touchStart',[blur]);await input('touchMove',[{x:blur.x-25,y:blur.y+10}]);
  await js("window.dispatchEvent(new Event('blur'))");await input('touchCancel',[]);result.blurClears=await idle();
  // Near-edge expansion and closing, and pickup while that animation is running.
  result.edges=[];
  for(const p of [{x:area.x+29,y:area.y+29},{x:area.x+area.width-29,y:area.y+29},{x:area.x+29,y:area.y+area.height-29},{x:area.x+area.width-29,y:area.y+area.height-29}]){
   await at(p);await input('touchStart',[p]);await input('touchEnd',[]);await pause(330);
   const fits=await js("(()=>{const a=viewport.areas[0],els=[ball,document.querySelector('#quick'),document.querySelector('#card-monitor'),...entries.map(e=>e.b)];return els.every(el=>{const r=el.getBoundingClientRect();return r.left>=a.x-viewport.host.x&&r.top>=a.y-viewport.host.y&&r.right<=a.x+a.width-viewport.host.x&&r.bottom<=a.y+a.height-viewport.host.y;});})()");
   const opened=mode==='menu';await setMode('closed');await pause(130);
   const moving=await visual();await input('touchStart',[moving]);await input('touchMove',[{x:moving.x+12,y:moving.y+9}]);await input('touchEnd',[]);
   result.edges.push({opened,fits,interruptible:await idle(),stationary:sameHost()});
  }
  await at(center);const inter=await visual();await input('touchStart',[inter]);await input('touchMove',[{x:inter.x+32,y:inter.y+16}]);
  await Promise.all([setMode('closed'),setMode('menu'),setMode('closed')]);await input('touchCancel',[]);await pause(330);
  result.modeInterrupt=mode==='closed'&&await idle();
  const mouse=async(type,p,buttons,pointerType='mouse')=>win.webContents.debugger.sendCommand('Input.dispatchMouseEvent',{type,x:p.x-host.x,y:p.y-host.y,button:type==='mouseMoved'?'none':'left',buttons,clickCount:type==='mouseMoved'?0:1,pointerType});
  result.pointers={};
  for(const kind of ['mouse','pen']){const p=await visual(),end={x:p.x+38,y:p.y-17};await mouse('mouseMoved',p,0,kind);await mouse('mousePressed',p,1,kind);await mouse('mouseMoved',end,1,kind);await pause(24);const moving=near(await visual(),end)&&!!drag;if(kind==='mouse'){await mouse('mouseMoved',{x:host.x+1,y:host.y+342},0,kind);await pause(20);result.hoverIgnored=near(await visual(),end)&&!!drag;}await mouse('mouseReleased',end,0,kind);result.pointers[kind]=moving&&await idle();stationary&&=sameHost();}
  result.finalPaint=await paintCheck();result.finalPassthrough=await passThrough();
  await refreshDesktop();result.topologyRestores=await idle();
  result.hostBefore=host;result.hostAfter=win.getBounds();result.nativeWindowNeverMoved=stationary&&sameHost();
  result.ok=result.passthroughBefore&&result.offsetPreserved&&result.dragAnimationLive&&result.dragExpression&&result.releaseFollows&&result.releaseIdle&&result.passthroughAfter&&result.saved&&result.rapid24&&result.staleMessagesIgnored&&result.secondFingerIgnored&&result.cancelClears&&result.captureRecoversWithContact&&result.lostCaptureClears&&result.blurClears&&result.edges.every(e=>e.opened&&e.fits&&e.interruptible&&e.stationary)&&result.modeInterrupt&&result.hoverIgnored&&Object.values(result.pointers).every(Boolean)&&result.paintDuringDrag.ok&&result.paintAfterRelease.ok&&result.finalPaint.ok&&result.finalPassthrough&&result.topologyRestores&&result.nativeWindowNeverMoved;
  return result;
 }finally{
  try{await input('touchCancel',[]);}catch{}await finishDrag();win.webContents.debugger.detach();
  prefs.anchor=original;save();mode=originalMode;place(original,false);send({kind:'mode',value:mode});await pause(150);
 }
}

function radios(kind='All',state='keep'){
 if(!['All','WiFi','Bluetooth'].includes(kind)||!['keep','On','Off'].includes(state))throw new Error('无效的无线设置');
 return new Promise((resolve,reject)=>{const child=spawn('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(__dirname.replace('app.asar','app.asar.unpacked'),'native','Radio.ps1'),'-Kind',kind,'-State',state],{windowsHide:true,stdio:['ignore','pipe','ignore']});let output='';child.stdout.on('data',chunk=>output+=chunk.toString('utf8'));const timeout=setTimeout(()=>{child.kill();reject(new Error('无线设备响应超时'));},15000);child.on('error',()=>{clearTimeout(timeout);reject(new Error('无线接口不可用'));});child.on('exit',code=>{clearTimeout(timeout);try{if(code!==0)throw 0;resolve([].concat(JSON.parse(output||'[]')));}catch{reject(new Error('Windows 未允许更改无线设备'));}});});
}
function shouldYield(context,area){return !context.own&&(context.dialog||(!context.caption&&!context.maximized&&context.width>=area.width-4&&context.height>=area.height-4&&context.x<=area.x+2&&context.y<=area.y+2));}
async function smartTop(){
 if(qa||smartBusy||!win||win.isDestroyed()||blackWindows.length||gesture||dragRestore)return;smartBusy=true;
 try{const strategy=prefs.topMode||'smart';let yieldNow=false;if(strategy==='smart'&&mode==='closed'){const context=await rpc('system.foreground',{pid:process.pid});const p=screen.screenToDipPoint({x:context.x,y:context.y}),end=screen.screenToDipPoint({x:context.x+context.width,y:context.y+context.height});const adjusted={...context,x:p.x,y:p.y,width:end.x-p.x,height:end.y-p.y};yieldNow=screen.getAllDisplays().some(d=>shouldYield(adjusted,d.bounds));}
  if(gesture||dragRestore||blackWindows.length)return;
  if(yieldNow){if(win.isVisible()){win.hide();smartHidden=true;}}else if(smartHidden){smartHidden=false;win.showInactive();}
  const top=strategy!=='normal';if(win.isAlwaysOnTop()!==top)win.setAlwaysOnTop(top,'floating');
 }catch{}finally{smartBusy=false;}
}
async function call(method,args){switch(method){
 case 'init': return {prefs,placement:placement(prefs.anchor,false),config,startup:await rpc('startup.get'),icons:{WeChat:await rpc('icon',{key:'WeChat'}).catch(()=>null),Edge:await rpc('icon',{key:'Edge'}).catch(()=>null)},qa,qaDragOnly,qaVisualOnly};
 case 'audio.list':case 'audio.level':case 'audio.mute':case 'audio.default':case 'audio.step':case 'startup.get':case 'system.status':case 'system.night':case 'system.night.set':case 'system.brightness':case 'system.plans':case 'system.plan':case 'wifi.list':case 'wifi.connect':case 'wifi.disconnect':case 'bluetooth.list':case 'bluetooth.pair':case 'bluetooth.status':case 'bluetooth.reply':case 'bluetooth.remove':case 'bluetooth.connection':return rpc(method,args);
 case 'system.radios':return radios();
 case 'system.radio':return radios(args.kind,args.state);
 case 'config.save':config={...config,...args};return rpc('config.save',args);
 case 'shortcut.addPath':{const target=String(args.target||'').trim();if(!fs.existsSync(target))throw new Error('路径不存在');prefs.shortcuts.push({name:path.basename(target,path.extname(target)),target});save();return prefs.shortcuts;}
 case 'app.action':log(args.app+' · '+args.action);return rpc(method,args);
 case 'launch':return rpc('launch',args);
 case 'explorer':return rpc('launch',{target:path.join(process.env.WINDIR||'C:\\Windows','explorer.exe')});
 case 'monitor':prefs.monitorPinned=!prefs.monitorPinned;save();send({kind:'prefs',prefs});return true;
 case 'black':if(blackWindows.length)restoreBlack();else black();return true;
 case 'black.native':black();return true;
 case 'black.exit':restoreBlack();return true;

 case 'lock':return rpc('lock');
 case 'mode':await setMode(args.value);return true;
 case 'background':return {processes:await rpc('processes'),memory:app.getAppMetrics().reduce((sum,p)=>sum+(p.memory.workingSetSize||0),0)/1024,uptime:(Date.now()-started)/1000,logs:recent};
 case 'prefs':{const reposition='size' in args||'monitorPinned' in args;prefs={...prefs,...args};for(const [key,values] of Object.entries({surface:['classic','liquid','frost','flat','neon','clay'],layout:['honeycomb','ring','wings'],palette:['original','ocean','forest','sunset','lavender','graphite'],reveal:['smooth','spring','fade']}))if(!values.includes(prefs[key]))prefs[key]=values[0];prefs.size=Math.max(32,Math.min(72,+prefs.size));save();send({kind:'prefs',prefs});if(reposition)place();return prefs;}
 case 'startup':return rpc('startup.set',{value:args.value,path:process.execPath});
 case 'path.choose':{const result=await dialog.showOpenDialog(win,{properties:['openFile'],filters:[{name:'程序或文件',extensions:['exe','lnk','bat','cmd']},{name:'所有文件',extensions:['*']}]});if(result.canceled)return null;config[args.key]=result.filePaths[0];await rpc('config.save',{[args.key]:result.filePaths[0]});return result.filePaths[0];}
 case 'shortcut.add':{const d=await dialog.showOpenDialog(win,{properties:['openFile']});if(d.canceled)return null;const target=d.filePaths[0];prefs.shortcuts.push({name:path.basename(target,path.extname(target)),target});save();return prefs.shortcuts;}
 case 'shortcut.remove':prefs.shortcuts.splice(args.index,1);save();return prefs.shortcuts;
 case 'quit':app.quit();return true;
 case 'qa.report':if(qa){fs.writeFileSync(path.join(app.getPath('userData'),'qa-result.json'),JSON.stringify(args,null,2));return true;}return false;
 case 'qa.edges':{const checks=[];for(const display of screen.getAllDisplays()){const a=display.workArea;for(const anchor of [{x:a.x+15,y:a.y+15},{x:a.x+a.width-15,y:a.y+15},{x:a.x+15,y:a.y+a.height-15},{x:a.x+a.width-15,y:a.y+a.height-15}]){const c=fitCenter(anchor,'menu',a);checks.push(c.x-146>=a.x&&c.x+146<=a.x+a.width&&c.y-190>=a.y&&c.y+314<=a.y+a.height);}}return {count:checks.length,ok:checks.every(Boolean)};}
 case 'qa.policy':return {fullscreen:shouldYield({own:false,caption:false,x:0,y:0,width:1920,height:1080},{x:0,y:0,width:1920,height:1080}),maximized:!shouldYield({own:false,caption:false,maximized:true,x:0,y:0,width:1920,height:1080},{x:0,y:0,width:1920,height:1080}),own:!shouldYield({own:true,caption:false,x:0,y:0,width:1920,height:1080},{x:0,y:0,width:1920,height:1080})};
 case 'qa.black':{
  const check=async key=>{black();await new Promise(r=>setTimeout(r,500));const results=[];
   for(const b of blackWindows){const image=await b.webContents.capturePage(),pixels=image.toBitmap();let pure=true;for(let i=0;i<pixels.length;i+=4)if(pixels[i]||pixels[i+1]||pixels[i+2]||pixels[i+3]!==255){pure=false;break;}const bounds=b.getBounds(),display=screen.getDisplayMatching(bounds);results.push({pure,fullScreen:b.isFullScreen(),coversDisplay:JSON.stringify(bounds)===JSON.stringify(display.bounds),top:b.isAlwaysOnTop()});}
   const orbHidden=!win.isVisible(),b=blackWindows[0];b.webContents.sendInputEvent({type:'keyDown',keyCode:key});b.webContents.sendInputEvent({type:'keyUp',keyCode:key});await new Promise(r=>setTimeout(r,120));return {orbHidden,results,exited:blackWindows.length===0,restored:win.isVisible()};
  };
  const escape=await check('ESC'),space=await check('Space');return {escape,space,ok:[escape,space].every(c=>c.orbHidden&&c.exited&&c.restored&&c.results.length===screen.getAllDisplays().length&&c.results.every(r=>r.pure&&r.fullScreen&&r.coversDisplay&&r.top))};
 }
 case 'qa.touch':return qa?touchCheck():null;
 case 'qa.silhouette':{if(!qa)return null;const image=await win.webContents.capturePage({x:Math.round(fitCenter(prefs.anchor,mode,screen.getDisplayNearestPoint(prefs.anchor).workArea).x-win.getBounds().x-64),y:Math.round(fitCenter(prefs.anchor,mode,screen.getDisplayNearestPoint(prefs.anchor).workArea).y-win.getBounds().y-64),width:128,height:128}),pixels=image.toBitmap({scaleFactor:1}),size=image.getSize(),scale=Math.sqrt(pixels.length/(size.width*size.height*4)),width=Math.round(size.width*scale),height=Math.round(size.height*scale);const rows=[];for(let y=0;y<height;y++){let count=0;for(let x=0;x<width;x++){const i=(y*width+x)*4;if(pixels[i]>235&&pixels[i+1]>235&&pixels[i+2]>235&&pixels[i+3]>180)count++;}if(count)rows.push(count);}const widest=Math.max(0,...rows),first=rows[0]||0;return {firstRow:first,widest,flatTopRatio:widest?first/widest:1,ok:widest>10&&first/widest<.35};}
 case 'qa.capture':if(qa){if(args.name==='menu')fs.writeFileSync(path.join(qaCaptureDir,'qa-orb.svg'),await win.webContents.executeJavaScript("document.querySelector('#avatar svg').outerHTML"));const local=await win.webContents.executeJavaScript("(()=>{const r=document.querySelector('#scene').getBoundingClientRect();return {x:r.x,y:r.y};})()");const rect=args.rect||{x:0,y:0,width:640,height:640};const image=await win.webContents.capturePage({...rect,x:Math.round(local.x+rect.x),y:Math.round(local.y+rect.y)});const p=path.join(qaCaptureDir,'qa-'+args.name+'.png');fs.writeFileSync(p,image.toPNG());return p;}return null;
 default:throw new Error('未知操作');}}
if(!app.requestSingleInstanceLock()){app.quit();}else{
 app.on('second-instance',(_,argv)=>{if(argv.includes('--quit')){app.quit();return;}if(win){win.showInactive();setMode(mode==='closed'?'menu':'closed');}});
 app.whenReady().then(async()=>{
  if(process.argv.includes('--quit'))return app.quit();
  startBridge();config=await rpc('config.get');
  const d=screen.getPrimaryDisplay().workArea;if(!prefs.anchor||!Number.isFinite(prefs.anchor.x)||!Number.isFinite(prefs.anchor.y))prefs.anchor={x:d.x+d.width-75,y:d.y+Math.round(d.height*.45)};const currentArea=screen.getDisplayNearestPoint(prefs.anchor).workArea;prefs.anchor.x=Math.max(currentArea.x+28,Math.min(prefs.anchor.x,currentArea.x+currentArea.width-28));prefs.anchor.y=Math.max(currentArea.y+28,Math.min(prefs.anchor.y,currentArea.y+currentArea.height-28));prefs.size=Math.max(32,Math.min(72,Number(prefs.size)||48));
  win=new BrowserWindow({...desktopBounds(),frame:false,transparent:true,backgroundColor:'#00000000',hasShadow:false,thickFrame:false,resizable:false,show:false,skipTaskbar:true,alwaysOnTop:prefs.topMode!=='normal',title:'Orbit Desktop',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
  // Windows may constrain the constructor's size to the work area. Establish
  // the actual desktop viewport before the first frame or touch can arrive.
  win.setBounds(desktopBounds(),false);win.webContents.setZoomFactor(1);win.webContents.setVisualZoomLevelLimits(1,1);
  win.on('close',event=>{if(!quitting){event.preventDefault();win.hide();}});
  win.on('show',()=>{if(blackWindows.length)win.hide();});
  win.on('blur',()=>{setTimeout(()=>{if(!qa&&win&&!win.isDestroyed()&&mode==='menu'&&!win.isFocused()&&!gesture&&!dragRestore&&!blackWindows.length)setMode('closed');},300);});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',event=>event.preventDefault());
  ipcMain.handle('call',async(_,m,a)=>{try{return {ok:true,result:await call(m,a||{})};}catch(e){log(e.message);return {ok:false,error:e.message};}});
  ipcMain.on('black-exit',event=>{if(blackWindows.some(b=>!b.isDestroyed()&&b.webContents===event.sender))restoreBlack();});
  ipcMain.on('event',(event,type,data)=>{
   if(event.sender!==win.webContents)return;
   if(type==='shape'){
    if(inputTest||gesture||dragRestore)return;if(!Array.isArray(data)||!data.length||data.length>1600)return;
    const rects=data.filter(r=>['x','y','width','height'].every(k=>Number.isInteger(r[k]))&&r.width>0&&r.height>0);
    if(rects.length)win.setShape(rects);
   }else if(type==='renderer-error'){log(String(data));}
   else if(type==='gesture-arm')armGesture(data);
   else if(type==='drag-start')startDrag(data);
   else if(type==='drag-move')updateDrag(data);
   else if(type==='gesture-end')commitGesture(data);
   else if(type==='context'){Menu.buildFromTemplate([{label:'设置',click:()=>send({kind:'open-tool',tool:'settings'})},{label:'后台',click:()=>send({kind:'open-tool',tool:'background'})},{type:'separator'},{label:'退出',click:()=>app.quit()}]).popup({window:win});}
  });
  await win.loadFile(path.join(__dirname,'index.html'));place(prefs.anchor,false);await win.webContents.executeJavaScript('window.orbitViewportReady()');win.showInactive();win.setIgnoreMouseEvents(false);
  const iconPath=path.join(__dirname,'orbit.png');tray=new Tray(nativeImage.createFromPath(iconPath).resize({width:24,height:24}));tray.setToolTip('Orbit');tray.setContextMenu(Menu.buildFromTemplate([{label:'打开',click:()=>{win.showInactive();setMode('menu');}},{label:'设置',click:()=>{win.showInactive();send({kind:'open-tool',tool:'settings'});}},{label:'隐藏 / 显示',click:()=>win.isVisible()?win.hide():win.showInactive()},{type:'separator'},{label:'退出',click:()=>app.quit()}]));tray.on('click',()=>{win.showInactive();setMode(mode==='closed'?'menu':'closed');});
  globalShortcut.register('Control+Alt+Space',()=>{win.showInactive();setMode(mode==='closed'?'menu':'closed');});
  for(const event of ['display-added','display-removed','display-metrics-changed'])screen.on(event,()=>refreshDesktop().catch(e=>log(e.message)));
  timer=setInterval(()=>{if(!win||!win.isVisible()||gesture||dragRestore)return;const p=screen.getCursorScreenPoint(),b=win.getBounds();send({kind:'pointer',x:p.x-b.x,y:p.y-b.y});},8);
  smartTimer=setInterval(smartTop,400);
  log('Orbit 已启动');if(qa)setTimeout(()=>setMode('menu'),250);
 }).catch(e=>{fs.mkdirSync(app.getPath('userData'),{recursive:true});fs.writeFileSync(path.join(app.getPath('userData'),'startup-error.txt'),e.stack);app.quit();});
 app.on('before-quit',()=>{quitting=true;clearInterval(timer);clearInterval(moveTimer);clearInterval(smartTimer);globalShortcut.unregisterAll();if(bridge&&!bridge.killed){bridge.stdin.end();bridge.kill();}if(tray)tray.destroy();});
 app.on('window-all-closed',()=>app.quit());
}
