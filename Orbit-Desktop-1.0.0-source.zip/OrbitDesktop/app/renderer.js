const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)], scene=$('#scene'),hive=$('#hive'),ball=$('#ball'),panel=$('#panel'),content=$('#content');
const avatar=window.OrbitCharacter;const availableStates=avatar.states;$('#avatar').appendChild(avatar.root);
let prefs={},config={},icons={},mode='closed',tool='',pointer={x:320,y:320},entries=[],dragStart=null,dragging=false,press=false,pan=0,targetPan=0,interactive=false,demo=false,demoAt=0,demoIndex=0,returnAt=0,testing=false,initReady=false,blackActive=false;
let sample=[],lastFrame=0,audioFlow=0,audioDevices=[],audioDevice=null,backgroundTimer,quickPoll,errorCount=0;const quickTouched=[0,0];
const stateNames={idle:'待机',listening:'聆听',thinking:'思考',streaming:'输出',searching:'搜索',reading:'阅读',working:'工作',coding:'编码',running:'运行',computing:'计算',controlling:'操控',waiting:'等待',blocked:'受阻',finished:'完成',failed:'失败',sleeping:'睡眠',waking:'醒来',happy:'开心',excited:'兴奋',laughing:'大笑',proud:'得意',curious:'好奇',playful:'玩耍',shy:'害羞',surprised:'惊讶',suspicious:'怀疑',angry:'生气',confused:'困惑',sad:'难过',drowsy:'困倦',bored:'无聊',scared:'害怕',celebrate:'庆祝',approving:'认可',orbit:'轨道',radar:'雷达',progress:'进度',spawning:'出现',loading:'加载',dictating:'听写',sending:'发送',receiving:'接收',uploading:'上传',writing:'书写',alerting:'提醒',bouncing:'弹跳','powering-down':'休眠',humming:'哼唱',notifying:'通知',dragging:'拖动',logo:'原版',showcase:'展示',turntable:'转身'};
async function api(method,args={}){const v=await window.orbit.call(method,args);if(!v.ok)throw new Error(v.error);return v.result;}
function safe(fn){return async(...args)=>{try{return await fn(...args);}catch(e){toast(e.message);}};}
let toastTimer;function toast(text){$('#toast').textContent=text;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),2200);}
function animation(name,duration=0,manual=false){if(!avatar.states.includes(name))return;avatar.select(name);returnAt=duration?performance.now()+duration:0;}

const orbitSurfaces=[['classic','经典'],['liquid','液态玻璃'],['frost','磨砂'],['flat','极简'],['neon','霓虹'],['clay','软陶']];
const orbitLayouts=[['honeycomb','蜂窝'],['ring','圆环'],['wings','双翼']];
const orbitPalettes=[['original','多彩','141,157,186'],['ocean','海蓝','28,149,255'],['forest','森林','30,183,119'],['sunset','落日','244,112,70'],['lavender','暮紫','158,93,242'],['graphite','石墨','154,164,180']];
const orbitReveals=[['smooth','舒展'],['spring','弹性'],['fade','渐显']];
function orbitPosition(index,q,r,size,layout){
 const spacing=Math.min(1.07,Math.max(1,(size/2+27)/53));
 if(index>=12&&layout!=='honeycomb')return {x:((index-12)%5-2)*50,y:152+Math.floor((index-12)/5)*50};
 if(layout==='ring'){const a=-Math.PI/2+index*Math.PI/6;return {x:Math.cos(a)*96,y:Math.sin(a)*96};}
 if(layout==='wings'){const side=index<6?-1:1,i=index%6;return {x:side*(66+(i%2)*48),y:(Math.floor(i/2)-1)*48};}
 return {x:(q*53+r*26.5)*spacing,y:r*45.9*spacing};
}
const orbitTones={
 original:['26,190,150','72,175,146','35,145,255','220,79,213','0,194,161','120,94,239','67,117,255','0,179,237','104,137,231','177,93,246','240,142,61','115,137,214'],
 ocean:['28,149,255','0,188,215','77,106,245'],forest:['30,183,119','14,164,156','111,177,55'],sunset:['244,112,70','232,153,43','222,82,121'],lavender:['158,93,242','203,86,199','102,116,240'],graphite:['134,147,170','108,124,148','156,166,182']
};
function orbitColor(rgb,index,palette){const tones=orbitTones[palette||'original'];return tones?tones[palette==='original'||!palette?index%tones.length:0]:rgb;}

function presetChoices(parent,label,key,choices){const title=document.createElement('div');title.className='preset-title';title.textContent=label;parent.appendChild(title);const group=document.createElement('div');group.className='preset-choices'+(key==='palette'?' palette-choices':'');group.setAttribute('role','group');group.setAttribute('aria-label',label);for(const [value,text,rgb] of choices){const b=button(text,()=>changePrefs({[key]:value}),'preset-choice');b.dataset.pref=key;b.dataset.value=value;if(rgb){const dots=document.createElement('span');dots.className='palette-swatch';dots.style.setProperty('--swatch',rgb);b.prepend(dots);}group.appendChild(b);}parent.appendChild(group);syncPresetChoices();}
function syncPresetChoices(){for(const b of $$('.preset-choice')){const selected=(prefs[b.dataset.pref]||({surface:'classic',layout:'honeycomb',palette:'original',reveal:'smooth'}[b.dataset.pref]))===b.dataset.value;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));}}

function applyPrefs(p){const oldSize=prefs.size,oldLayout=prefs.layout,oldPalette=prefs.palette;prefs=p;const style=document.documentElement.style;style.setProperty('--ball',p.size+'px');style.setProperty('--opacity',p.opacity??.66);style.setProperty('--glass',p.glass??.2);style.setProperty('--shine',p.highlight??.12);style.setProperty('--monitor-font',(p.monitorFont||16)+'px');document.documentElement.dataset.theme=p.theme==='system'||!p.theme?(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'):p.theme;document.documentElement.dataset.surface=p.surface||'classic';style.setProperty('--accent',orbitColor('28,149,255',0,p.palette));document.documentElement.dataset.palette=p.palette||'original';document.documentElement.dataset.reveal=p.reveal||'smooth';syncPresetChoices();scene.classList.toggle('monitor-pinned',!!p.monitorPinned);scene.classList.toggle('monitor-compact',!!p.monitorCompact);if(initReady&&(oldSize!==p.size||oldLayout!==p.layout||oldPalette!==p.palette))buildHive();}
function button(text,action,cls='action'){const b=document.createElement('button');b.className=cls;b.textContent=text;b.onclick=safe(action);return b;}
function row(...children){const d=document.createElement('div');d.className='row';children.forEach(c=>d.appendChild(c));content.appendChild(d);return d;}
function image(name){const img=document.createElement('img');img.src='icons/'+name+'.svg';img.draggable=false;return img;}
function iconButton(icon,label,action){const b=button('',action,'icon-button');b.setAttribute('aria-label',label);b.appendChild(image(icon));return b;}
function toggle(text,value,action){const label=document.createElement('label');label.className='toggle-row';const copy=document.createElement('span');copy.textContent=text;const input=document.createElement('input');input.type='checkbox';input.className='switch';input.checked=value;input.onchange=safe(()=>action(input.checked));label.append(copy,input);content.appendChild(label);return input;}
function section(text){const s=document.createElement('div');s.className='section-title';s.textContent=text;content.appendChild(s);}
function metric(name,value){const d=document.createElement('div');d.className='metric';const a=document.createElement('span'),b=document.createElement('span');a.textContent=name;b.textContent=value;d.append(a,b);content.appendChild(d);}
function slider(value,action){const input=document.createElement('input');input.type='range';input.min=0;input.max=100;input.value=value;input.className='slider';input.style.setProperty('--value',value+'%');input.oninput=()=>{input.style.setProperty('--value',input.value+'%');action(+input.value);};content.appendChild(input);return input;}
function visualMode(next){if(next!==mode)shapeExpandedUntil=performance.now()+650;if(next!=='menu'&&cardsReady)hideControlCard();const previous=mode;mode=next;panel.hidden=mode!=='tool';hive.inert=next!=='menu';$('#quick').inert=next!=='menu';if(next==='menu'&&previous!=='menu'){targetPan=pan=0;scene.classList.remove('expanded');buildHive();void hive.offsetWidth;scene.classList.add('expanded');safe(refreshQuick)();clearInterval(quickPoll);quickPoll=setInterval(()=>{for(const [flow,id] of [[0,'quick-output'],[1,'quick-microphone']]){if(Date.now()-quickTouched[flow]<800)continue;api('audio.list',{flow}).then(list=>$('#'+id)._update?.(list)).catch(()=>{});}if(Date.now()-nightTouched>1000)refreshNight().catch(()=>{});},1200);}else scene.classList.toggle('expanded',mode==='menu');if(next!=='menu')clearInterval(quickPoll);if(next!=='tool'){tool='';clearInterval(backgroundTimer);}}
async function setMode(next){visualMode(next);await api('mode',{value:next});}
function buildHive(){hive.replaceChildren();entries=[];const items=[
 ['微信','wechat','45,53,65',-1,0,()=>openTool('WeChat'),'WeChat'],['Edge','browser','113,157,139',1,0,()=>openTool('Edge'),'Edge'],
 ['音频','volume-2','72,157,255',0,-1,()=>showAudioCard(0)],['麦克风','mic','214,107,222',1,-1,()=>showAudioCard(1)],
 ['文件管理','folder-open','53,221,183',-1,1,async()=>{await api('explorer');await setMode('closed');}],['黑屏','moon','113,119,192',0,1,async()=>{await setMode('closed');await api('black');}],
 ['蓝牙','bluetooth','79,135,255',-1,-1,()=>showBluetooth()],['Wi-Fi','wifi','98,189,255',1,-2,()=>showWifi()],
 ['设置','settings-2','182,194,222',2,-1,()=>openTool('settings')],['表情','smile','172,126,255',1,1,()=>openTool('animation')],
 ['锁屏','lock-keyhole','249,160,107',-1,2,async()=>{await setMode('closed');await api('lock');}],['添加','plus','180,198,232',-2,1,()=>openTool('shortcuts')]
 ];(prefs.shortcuts||[]).forEach((s,i)=>items.push([s.name,'folder-open','127,172,225',i%5-2,3+Math.floor(i/5),async()=>{await setMode('closed');await api('launch',{target:s.target});}]));
 for(const [index,[name,icon,rgb,q,r,action,appIcon]] of items.entries()){const b=button('',async()=>{await action();},'tile hit');const {x,y}=orbitPosition(index,q,r,prefs.size,prefs.layout||'honeycomb'),distance=Math.hypot(x,y);b.style.setProperty('--x',x+'px');b.style.setProperty('--y',y+'px');b.style.setProperty('--rgb',orbitColor(rgb,index,prefs.palette));b.style.setProperty('--diam','40px');b.style.setProperty('--delay',Math.round(distance*.6)+'ms');b.setAttribute('aria-label',name);b.dataset.kind=icon;let img=image(icon);if(appIcon&&icons[appIcon]){img.src=icons[appIcon];img.classList.add('app-icon');}b.appendChild(img);b.onmouseenter=()=>{$('#label').textContent=name;$('#label').classList.add('show');};b.onmouseleave=()=>$('#label').classList.remove('show');hive.appendChild(b);entries.push({b,x,y});}
}
function focusQuick(id){hideControlCard();const bar=$('#'+id);bar.classList.add('focused');(bar.matches('button,input')?bar:bar.querySelector('input,button'))?.focus();setTimeout(()=>bar.classList.remove('focused'),600);}
async function refreshQuick(){await Promise.all([quickBar(0,$('#quick-output')),brightnessBar($('#quick-brightness'))]);}
async function quickBar(flow,bar){
 const [devices,inputs]=await Promise.all([api('audio.list',{flow:0}),api('audio.list',{flow:1})]);bar.replaceChildren();if(!devices.length)return;
 let device=devices.find(d=>d.isDefault)||devices[0],mic=inputs.find(d=>d.isDefault)||inputs[0],levelTimer;
 const mute=iconButton('volume-2','输出静音',async()=>{await api('audio.mute',{id:device.id,value:!device.muted});device.muted=!device.muted;sync();});
 const range=document.createElement('input');range.type='range';range.min=0;range.max=100;range.className='slider';range.setAttribute('aria-label','输出音量');
 const number=document.createElement('span');number.className='quick-value';
 const micButton=iconButton('mic','麦克风静音',async()=>{if(!mic)return;quickTouched[1]=Date.now();await api('audio.mute',{id:mic.id,value:!mic.muted});mic.muted=!mic.muted;syncMic();});micButton.id='quick-microphone';micButton.classList.add('mic-button');
 const syncMic=()=>{micButton.disabled=!mic;micButton.classList.toggle('mic-muted',!!mic?.muted);micButton.setAttribute('aria-pressed',mic?.muted?'true':'false');micButton.setAttribute('aria-label',mic?.muted?'取消麦克风静音':'麦克风静音');};
 micButton._update=list=>{mic=list.find(d=>d.isDefault)||list[0];syncMic();};
 const sync=()=>{range.value=Math.round(device.level*100);range.style.setProperty('--value',range.value+'%');number.textContent=range.value+'%';mute.classList.toggle('muted',device.muted);};
 range.oninput=()=>{quickTouched[0]=Date.now();const value=+range.value/100,id=device.id;device.level=value;number.textContent=range.value+'%';range.style.setProperty('--value',range.value+'%');clearTimeout(levelTimer);levelTimer=setTimeout(()=>safe(()=>api('audio.level',{id,value}))(),20);};
 bar.append(mute,range,number,micButton);bar._update=list=>{if(Date.now()-quickTouched[0]<800||mode!=='menu')return;if(list.map(d=>d.id).join('|')!==devices.map(d=>d.id).join('|')){quickBar(0,bar).catch(()=>{});return;}const next=list.find(d=>d.isDefault)||list[0];if(next){device=next;sync();}};sync();syncMic();
}
let brightnessTouched=0;
async function brightnessBar(bar){
 const data=await api('system.status');bar.replaceChildren();const sun=document.createElement('span');sun.className='brightness-symbol';sun.appendChild(image('sun'));
 const input=document.createElement('input');input.type='range';input.className='slider';input.id='quick-brightness-range';input.min=0;input.max=100;input.setAttribute('aria-label','屏幕亮度');const number=document.createElement('span');number.className='quick-value';number.id='quick-brightness-value';let timer;
 input.oninput=()=>{brightnessTouched=Date.now();number.textContent=input.value+'%';input.style.setProperty('--value',input.value+'%');clearTimeout(timer);const value=+input.value;timer=setTimeout(()=>safe(()=>api('system.brightness',{value}))(),60);};const night=iconButton('moon','夜间模式',toggleNight);night.id='quick-night-button';night.classList.add('night-button');bar.append(sun,input,number,night);syncBrightness(data);syncNight();await refreshNight();
}
function syncBrightness(data){for(const id of ['brightness','quick-brightness-range']){const input=$('#'+id);if(!input)continue;input.disabled=data.brightness==null;if(data.brightness!=null&&document.activeElement!==input&&Date.now()-brightnessTouched>1000){input.value=data.brightness;input.style.setProperty('--value',data.brightness+'%');}}const value=$('#quick-brightness-value');if(value&&Date.now()-brightnessTouched>1000)value.textContent=data.brightness==null?'—':data.brightness+'%';}

let nightState={supported:false,enabled:false},nightTouched=0,nightBusy=false,nightVersion=0;
async function refreshNight(){
 if(nightBusy)return;const version=nightVersion,state=await api('system.night');
 if(nightBusy||version!==nightVersion)return;nightState=state;syncNight();
}
async function toggleNight(){
 if(nightBusy)return;nightBusy=true;nightTouched=Date.now();nightVersion++;syncNight();
 try{const current=await api('system.night');nightState=current;if(!current.supported)throw new Error('系统夜间模式不可用');nightState=await api('system.night.set',{enabled:!current.enabled});}
 finally{nightBusy=false;nightTouched=Date.now();nightVersion++;syncNight();}
}
function syncNight(){
 const button=$('#quick-night-button');if(!button)return;
 button.disabled=nightBusy||!nightState.supported;button.classList.toggle('selected',nightState.enabled);
 button.setAttribute('role','switch');button.setAttribute('aria-checked',String(nightState.enabled));button.setAttribute('aria-busy',String(nightBusy));
 button.title=nightState.supported?(nightState.enabled?'关闭夜间模式':'开启夜间模式'):'系统夜间模式不可用';
}

let cardTimer=null,systemData={},radioData=[],cardsReady=false,activeCard='';
function makeCard(id,title,x,y,w,h){const card=document.createElement('section');card.id=id;card.className='inline-card hit';card.inert=id!=='card-monitor';Object.assign(card.style,{left:x+'px',top:y+'px',width:w+'px',height:h+'px'});const heading=document.createElement('h2');heading.textContent=title;const body=document.createElement('div');body.className='card-body';card.append(heading,body);if(id!=='card-monitor'){const close=iconButton('x','收起卡片',()=>hideControlCard());close.classList.add('card-close');card.appendChild(close);}$('#cards').appendChild(card);return body;}
function appendRow(parent,...children){const r=document.createElement('div');r.className='card-row';r.append(...children);parent.appendChild(r);return r;}
function field(parent,label,element){const l=document.createElement('label');l.className='card-field';const copy=document.createElement('span');copy.textContent=label;l.append(copy,element);parent.appendChild(l);return element;}
function inlineSelect(items,value,action,label){const s=document.createElement('button');s.className='choice-button action';let choices=items,current=String(value);const sync=()=>{const text=choices.find(i=>String(i[0])===current)?.[1]||'—';s.textContent=text+(choices.length>1?'  ›':'');s.setAttribute('aria-label',label+'：'+text);s.disabled=choices.length<2;};Object.defineProperty(s,'value',{get:()=>current,set:v=>{current=String(v);sync();}});s.setItems=list=>{choices=list;if(!choices.some(i=>String(i[0])===current)&&choices.length)current=String(choices[0][0]);sync();};s.onclick=safe(async()=>{const before=current,index=Math.max(0,choices.findIndex(i=>String(i[0])===current));s.value=choices[(index+1)%choices.length][0];try{await action(current);}catch(e){s.value=before;throw e;}});sync();return s;}
function inlineRange(parent,label,value,min,max,action){const s=document.createElement('input');s.type='range';s.className='slider';s.min=min;s.max=max;s.value=value;s.setAttribute('aria-label',label);s.style.setProperty('--value',(value-min)/(max-min)*100+'%');s.oninput=()=>{s.style.setProperty('--value',(+s.value-min)/(max-min)*100+'%');safe(()=>action(+s.value))();};field(parent,label,s);return s;}
function inlineToggle(parent,label,value,action){const s=document.createElement('input');s.type='checkbox';s.className='switch';s.checked=value;s.onchange=safe(()=>action(s.checked));return field(parent,label,s);}
const changePrefs=patch=>api('prefs',patch);
async function launchApp(name,action='show'){await api('app.action',{app:name,action});if(action==='show')await setMode('closed');}
function hideControlCard(){++audioCardRequest;activeCard='';for(const e of entries)e.b.classList.remove('is-active');scene.classList.remove('has-control-card');for(const c of $$('.inline-card:not(#card-monitor)')){c.classList.remove('active-card');c.inert=true;}$('#quick').inert=mode!=='menu';}
async function openTool(name){if(name==='audio'||name==='mic')return showAudioCard(name==='mic'?1:0);const map={WeChat:'card-chat',Edge:'card-code',settings:'card-settings',background:'card-background',animation:'card-expressions',shortcuts:'card-shortcuts',audio:'quick-output',mic:'quick-input'};const id=map[name]||name;const wasOpen=mode==='menu'&&activeCard===id;await setMode('menu');if(wasOpen){hideControlCard();return;}hideControlCard();const card=$('#'+id);if(!card)return;activeCard=id;const activeNames={'card-chat':'微信','card-code':'Edge','card-settings':'设置','card-expressions':'表情','card-shortcuts':'添加','card-wifi':'Wi-Fi','card-bluetooth':'蓝牙','card-audio':'音频','card-mic':'麦克风'};for(const e of entries)e.b.classList.toggle('is-active',e.b.getAttribute('aria-label')===activeNames[id]);card.inert=false;card.classList.add('active-card');scene.classList.add('has-control-card');$('#quick').inert=true;if(name==='animation')$('#animation-state').focus();if(name==='settings')refreshAudioChoices();}
async function updateRadios(){try{radioData=await api('system.radios');for(const kind of ['WiFi','Bluetooth']){const b=$('#radio-'+kind),r=radioData.find(r=>r.kind===kind);if(b){b.classList.toggle('selected',r?.state==='On');b.setAttribute('aria-pressed',r?.state==='On'?'true':'false');b.disabled=!r;}}}catch{for(const b of $$('.radio-toggle'))b.disabled=true;}}
async function toggleRadio(kind){const r=radioData.find(r=>r.kind===kind);if(!r)return toast('设备不可用');await api('system.radio',{kind,state:r.state==='On'?'Off':'On'});await updateRadios();}
function bytes(v){if(v>=1048576)return (v/1048576).toFixed(1)+' MB/s';return Math.round((v||0)/1024)+' KB/s';}
async function refreshStatus(){try{systemData=await api('system.status');const values={cpu:systemData.cpu==null?'—':Math.round(systemData.cpu)+'%',gpu:systemData.gpu==null?'—':Math.round(systemData.gpu)+'%',memory:systemData.memory==null?'—':systemData.memory+'%',power:systemData.watts!=null?systemData.watts.toFixed(1)+' W':systemData.external?'插电':'—'};for(const [id,value]of Object.entries(values))$('#metric-'+id).textContent=value;$('#metric-network').textContent='↓ '+bytes(systemData.download)+'   ↑ '+bytes(systemData.upload);$('#metric-ram-total').textContent=systemData.usedGB!=null?systemData.usedGB+' / '+systemData.totalGB+' GB':'';syncBrightness(systemData);}catch{}}
async function refreshBackground(){if(mode!=='menu')return;try{const data=await api('background');$('#orbit-memory').textContent=Math.round(data.memory)+' MB';for(const p of data.processes.filter(p=>['WeChat','Edge'].includes(p.name))){const el=$('#process-'+p.name);if(el)el.textContent=p.count?(p.memory>=1024?(p.memory/1024).toFixed(1)+' GB':Math.round(p.memory)+' MB'):'未运行';}}catch{}}

function selectSettingsPage(name){
 for(const p of $$('#card-settings .settings-page'))p.hidden=p.dataset.page!==name;
 for(const b of $$('#card-settings [role=tab]')){const active=b.dataset.page===name;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;}
 const body=$('#card-settings .card-body');if(body)body.scrollTop=0;
}
function buildSettingsPages(body){
 const tabs=document.createElement('div');tabs.className='settings-tabs';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','设置分类');body.appendChild(tabs);const pages={};
 for(const [key,title] of [['style','风格'],['layout','布局配色'],['control','控制']]){
  const b=button(title,()=>selectSettingsPage(key),'settings-tab');b.dataset.page=key;b.id='settings-tab-'+key;b.setAttribute('role','tab');b.setAttribute('aria-controls','settings-page-'+key);
  b.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const all=[...tabs.children],i=all.indexOf(b),next=all[e.key==='Home'?0:e.key==='End'?all.length-1:(i+(e.key==='ArrowRight'?1:all.length-1))%all.length];next.click();next.focus();};tabs.appendChild(b);
  const page=document.createElement('div');page.className='settings-page';page.dataset.page=key;page.id='settings-page-'+key;page.setAttribute('role','tabpanel');page.setAttribute('aria-labelledby',b.id);body.appendChild(page);pages[key]=page;
 }
 selectSettingsPage('style');return pages;
}

function buildCards(){
 $('#cards').replaceChildren();makeCard('card-devices','音频设备',180,448,280,176);makeCard('card-audio','音频输出',180,448,280,176);makeCard('card-mic','麦克风',180,448,280,176);makeCard('card-wifi','Wi-Fi',180,448,280,176);makeCard('card-bluetooth','蓝牙',180,448,280,176);
 const monitor=makeCard('card-monitor','实时监控',180,24,280,116);const grid=document.createElement('div');grid.className='metrics-grid';for(const [id,name]of [['cpu','CPU'],['gpu','GPU'],['memory','内存'],['power','功耗']]){const item=document.createElement('div'),v=document.createElement('strong'),l=document.createElement('span');v.id='metric-'+id;v.textContent='—';l.textContent=name;item.append(v,l);grid.appendChild(item);}const net=document.createElement('div');net.id='metric-network';net.className='net-speed';const mem=document.createElement('div');mem.id='metric-ram-total';mem.className='memory-caption';monitor.append(grid,net,mem);
 for(const [app,id,y]of [['WeChat','card-chat',160],['Edge','card-code',280]]){const body=makeCard(id,app==='WeChat'?'微信':app,12,y,144,116);body.appendChild(button('打开',()=>launchApp(app),'action launch-app'));body.appendChild(button('选择程序',async()=>{const target=await api('path.choose',{key:app});if(target)config[app]=target;},'action locate-app'));appendRow(body,iconButton('minus','最小化 '+app,()=>launchApp(app,'minimize')),iconButton('pin','置顶 '+app,()=>launchApp(app,'top')),iconButton('x','关闭 '+app,()=>launchApp(app,'close')));}
 const settingsBody=makeCard('card-settings','外观与控制',484,160,144,312);
 const settingsPages=buildSettingsPages(settingsBody),settings=settingsPages.control;
 presetChoices(settingsPages.style,'界面风格','surface',orbitSurfaces);
 presetChoices(settingsPages.layout,'展开布局','layout',orbitLayouts);presetChoices(settingsPages.layout,'配色','palette',orbitPalettes);presetChoices(settingsPages.layout,'展开动效','reveal',orbitReveals);
 field(settings,'置顶',inlineSelect([['smart','智能'],['always','始终'],['normal','普通']],prefs.topMode||'smart',value=>changePrefs({topMode:value}),'置顶策略'));
 field(settings,'主题',inlineSelect([['system','跟随系统'],['dark','暗色'],['light','亮色']],prefs.theme||'system',value=>changePrefs({theme:value}),'展开主题'));
 inlineRange(settings,'底色',Math.round((prefs.opacity??.66)*100),15,100,v=>changePrefs({opacity:v/100}));
 inlineRange(settings,'玻璃',Math.round((prefs.glass??.2)*100),0,100,v=>changePrefs({glass:v/100}));
 inlineRange(settings,'高光',Math.round((prefs.highlight??.12)*100),0,60,v=>changePrefs({highlight:v/100}));
 inlineRange(settings,'球体',prefs.size,32,72,v=>changePrefs({size:v}));
 inlineToggle(settings,'常驻监控',prefs.monitorPinned||false,v=>changePrefs({monitorPinned:v}));
 inlineToggle(settings,'简洁监控',prefs.monitorCompact||false,v=>changePrefs({monitorCompact:v}));
 inlineRange(settings,'监控字号',prefs.monitorFont||16,14,24,v=>changePrefs({monitorFont:v}));
 inlineToggle(settings,'鼠标跟随',prefs.follow,v=>changePrefs({follow:v}));inlineToggle(settings,'动画',prefs.animate,v=>changePrefs({animate:v}));
 const autostart=inlineToggle(settings,'开机启动',false,v=>api('startup',{value:v}));api('startup.get').then(v=>autostart.checked=v).catch(()=>{});
 const expressionBody=makeCard('card-expressions','表情',180,448,280,176);
 const autoExpression=inlineToggle(expressionBody,'球体动画',prefs.autoExpressions!==false,v=>changePrefs({autoExpressions:v}));autoExpression.id='auto-expressions';const animationSelect=inlineSelect(availableStates.map(n=>[n,stateNames[n]||n]),'logo',value=>{demo=false;autoExpression.checked=false;changePrefs({autoExpressions:false});animation(value,0,true);},'动画状态');animationSelect.id='animation-state';field(expressionBody,'表情',animationSelect);
 inlineToggle(expressionBody,'轮播',false,v=>{demo=v;demoAt=0;if(!v)animation('logo');});
 const bright=inlineRange(settings,'亮度',systemData.brightness??50,0,100,value=>{clearTimeout(bright._timer);bright._timer=setTimeout(()=>safe(()=>api('system.brightness',{value}))(),60);});bright.id='brightness';
 const plan=inlineSelect([],null,value=>api('system.plan',{id:value}),'电源模式');field(settings,'电源',plan);api('system.plans').then(list=>{plan.setItems(list.map(p=>[p.id,p.name]));plan.value=list.find(p=>p.active)?.id||list[0]?.id;}).catch(()=>{});
 for(const [key,name]of [['WeChat','微信路径'],['Edge','Edge 路径']]){const input=document.createElement('input');input.type='text';input.className='path-input';input.setAttribute('aria-label',name);input.value=config[key]||'';input.placeholder='自动检测，可手动指定';input.onchange=safe(()=>api('config.save',{[key]:input.value.trim()}));field(settings,name,input);}
 field(settings,'输出设备',inlineSelect([],null,id=>api('audio.default',{id}),'输出设备')).id='output-choice';field(settings,'输入设备',inlineSelect([],null,id=>api('audio.default',{id}),'输入设备')).id='input-choice';settings.appendChild(button('后台',()=>openTool('background')));
 const shortcuts=makeCard('card-shortcuts','快捷方式',12,522,144,106);const pathInput=document.createElement('input');pathInput.className='path-input';pathInput.placeholder='粘贴程序路径';pathInput.setAttribute('aria-label','快捷方式路径');const add=button('添加',async()=>{const target=pathInput.value.trim().replace(/^"|"$/g,'');if(!target)return;const list=await api('shortcut.addPath',{target});prefs.shortcuts=list;pathInput.value='';buildHive();renderShortcuts();});shortcuts.append(pathInput,add);const list=document.createElement('div');list.id='shortcut-list';shortcuts.appendChild(list);
 const background=makeCard('card-background','后台',484,484,144,144);for(const [id,name]of [['orbit-memory','Orbit'],['process-WeChat','微信'],['process-Edge','Edge']]){const row=document.createElement('div');row.className='process-row';const a=document.createElement('span'),b=document.createElement('strong');a.textContent=name;b.id=id;b.textContent='—';row.append(a,b);background.appendChild(row);}background.appendChild(button('退出 Orbit',()=>api('quit'),'action quit-app'));cardsReady=true;renderShortcuts();refreshStatus();refreshBackground();updateRadios();clearInterval(cardTimer);let tick=0;cardTimer=setInterval(()=>{if(mode==='menu'||prefs.monitorPinned)refreshStatus();if(mode==='menu'){refreshBackground();if(++tick%12===0)updateRadios();}},1000);
}
function renderShortcuts(){const list=$('#shortcut-list');if(!list)return;list.replaceChildren();for(const [index,item]of(prefs.shortcuts||[]).entries()){const r=document.createElement('div');r.className='shortcut-row';r.append(button(item.name,async()=>{await api('launch',{target:item.target});await setMode('closed');}),iconButton('x','移除 '+item.name,async()=>{prefs.shortcuts=await api('shortcut.remove',{index});renderShortcuts();buildHive();}));list.appendChild(r);}}

$('#close').onclick=safe(()=>setMode('closed'));
// Input, layout and drawing all use the same stationary desktop viewport.
let activePointer=null,lastMotionAt=-1,gestureSerial=0,gestureToken=0,dragSample=null,
 dragAnchor=null,dragFinishing=false,dragLook={x:0,y:0};
let viewport={host:{x:0,y:0},areas:[]},scenePosition={x:0,y:0},sceneMotion=null;
const point=e=>({x:e.clientX,y:e.clientY});
function centerOnDesktop(){return {x:viewport.host.x+scenePosition.x+320,y:viewport.host.y+scenePosition.y+320};}
function paintScene(){scene.style.transform=`translate3d(${scenePosition.x}px,${scenePosition.y}px,0)`;}
function advanceScene(now){
 if(!sceneMotion)return;
 const t=Math.min(1,(now-sceneMotion.at)/240),e=1-Math.pow(1-t,3);
 scenePosition={x:sceneMotion.from.x+(sceneMotion.to.x-sceneMotion.from.x)*e,y:sceneMotion.from.y+(sceneMotion.to.y-sceneMotion.from.y)*e};
 paintScene();if(t===1){sceneMotion=null;shapeKey='';}
}
function applyPlacement(data){
 if(activePointer!==null||data.token<gestureToken)return;
 viewport={host:data.host,areas:data.areas};
 const to={x:data.center.x-data.host.x-320,y:data.center.y-data.host.y-320};
 scene.classList.toggle('tool-left',data.left);
 if(data.animate&&initReady&&Math.hypot(to.x-scenePosition.x,to.y-scenePosition.y)>1){
  advanceScene(performance.now());sceneMotion={from:{...scenePosition},to,at:performance.now()};
 }else{sceneMotion=null;scenePosition=to;paintScene();}
 scene.classList.add('viewport-ready');shapeKey='';updateShape(performance.now(),true);
}
window.orbitViewportReady=()=>new Promise((resolve,reject)=>{
 const deadline=performance.now()+15000;
 const ready=()=>{if(initReady)requestAnimationFrame(()=>requestAnimationFrame(resolve));else if(performance.now()>deadline)reject(new Error('界面初始化超时'));else requestAnimationFrame(ready);};ready();
});
function paintDrag(){
 scenePosition={x:dragAnchor.x+dragSample.x-dragStart.x,y:dragAnchor.y+dragSample.y-dragStart.y};paintScene();
}
function finishDragVisual(data){
 // A completion for a previous finger must never reset a new gesture.
 if(data.token!==gestureToken||activePointer!==null)return;
 if(data.center){scenePosition={x:data.center.x-viewport.host.x-320,y:data.center.y-viewport.host.y-320};paintScene();}
 dragFinishing=false;shapeKey='';updateShape(performance.now(),true);
}
function endGesture(cancelled=false){
 if(activePointer===null)return null;
 const id=activePointer,token=gestureToken,wasDrag=dragging;
 if(wasDrag){const c=OrbitGeometry.release(centerOnDesktop(),prefs.size,viewport.areas);scenePosition={x:c.x-viewport.host.x-320,y:c.y-viewport.host.y-320};paintScene();}
 const center=centerOnDesktop();activePointer=null;press=false;dragging=false;dragFinishing=false;
 scene.classList.remove('dragging');dragSample=null;dragAnchor=null;
 if(ball.hasPointerCapture(id))ball.releasePointerCapture(id);
 window.orbit.send('gesture-end',{token,center});
 if(wasDrag){animation('idle');originalHeroStep=2;originalHeroAt=performance.now()+6800;}
 shapeKey='';updateShape(performance.now(),true);
 if(!wasDrag&&!cancelled)safe(()=>setMode(mode==='closed'?'menu':'closed'))();
 return {token,center};
}
window.cancelOrbitGesture=token=>token===gestureToken?endGesture(true):null;
ball.addEventListener('pointerdown',e=>{
 if(e.button!==0||!e.isPrimary||activePointer!==null||blackActive)return;e.preventDefault();
 sceneMotion=null;
 activePointer=e.pointerId;gestureToken=++gestureSerial;lastMotionAt=-1;press=true;dragging=false;
 dragStart=point(e);dragSample={...dragStart};dragAnchor={...scenePosition};dragLook={x:0,y:0};
 ball.setPointerCapture(e.pointerId);
 window.orbit.send('gesture-arm',{token:gestureToken,pointerId:activePointer,center:centerOnDesktop()});
});
function moveBall(e){
 if(e.pointerId!==activePointer||e.timeStamp<=lastMotionAt)return;
 // Windows may emit a hover at the physical cursor when the input region
 // changes. It is not a pressed-pointer sample and must not move the orb.
 if(e.buttons===0)return;
 lastMotionAt=e.timeStamp;e.preventDefault();
 // Use the newest physical sample. Predicted points introduce overshoot on release.
 const samples=e.getCoalescedEvents?.(),p=point(samples?.length?samples[samples.length-1]:e);
 if(dragSample){dragLook.x=Math.max(-.7,Math.min(.7,(p.x-dragSample.x)/14));dragLook.y=Math.max(-.7,Math.min(.7,-(p.y-dragSample.y)/14));}dragSample=p;
 if(!dragging&&Math.hypot(p.x-dragStart.x,p.y-dragStart.y)>(e.pointerType==='mouse'?5:3)){
  dragging=true;scene.classList.add('dragging');visualMode('closed');shapeExpandedUntil=0;
  animation('dragging',0,true);
  window.orbit.send('drag-start',{token:gestureToken,pointerId:activePointer,center:centerOnDesktop()});
 }
 if(dragging){paintDrag();window.orbit.send('drag-move',{token:gestureToken,pointerId:activePointer,center:centerOnDesktop()});}
}
window.addEventListener('pointermove',moveBall,{capture:true});window.addEventListener('pointerrawupdate',moveBall,{capture:true});
window.addEventListener('pointerup',e=>{if(e.pointerId!==activePointer)return;e.preventDefault();if(dragging){dragSample=point(e);paintDrag();}endGesture();},{capture:true});
window.addEventListener('pointercancel',e=>{if(e.pointerId===activePointer)endGesture(true);},{capture:true});
ball.addEventListener('lostpointercapture',e=>{
 if(e.pointerId!==activePointer)return;
 // Updating a Windows input region can release mouse capture while the button
 // remains held. Reacquire that live pointer; real cancellation/blur ends it.
 if(press&&e.buttons){try{ball.setPointerCapture(e.pointerId);return;}catch{}}
 endGesture(true);
});
window.addEventListener('blur',()=>endGesture(true));
document.addEventListener('visibilitychange',()=>{if(document.hidden)endGesture(true);});
ball.addEventListener('contextmenu',e=>{e.preventDefault();if(activePointer===null)window.orbit.send('context');});
ball.addEventListener('wheel',safe(async e=>{e.preventDefault();const volume=await api('audio.step',{delta:e.deltaY<0?.04:-.04});toast(Math.round(volume*100)+'%');}),{passive:false});
hive.addEventListener('wheel',e=>{if(mode==='menu'){e.preventDefault();targetPan=Math.max(-200,Math.min(140,targetPan-e.deltaY*.22));}},{passive:false});document.addEventListener('keydown',e=>{if(e.key==='Escape')safe(async()=>{if(blackActive)await api('black.exit');await setMode('closed');})();});
let hiveTouch=null,suppressTileClick=false;
hive.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'||!e.isPrimary||mode!=='menu')return;suppressTileClick=false;hiveTouch={id:e.pointerId,y:e.clientY,pan:targetPan,moved:false};});
hive.addEventListener('pointermove',e=>{if(!hiveTouch||e.pointerId!==hiveTouch.id)return;const delta=e.clientY-hiveTouch.y;if(!hiveTouch.moved&&Math.abs(delta)>9){hiveTouch.moved=true;hive.setPointerCapture(e.pointerId);$('#label').classList.remove('show');}if(hiveTouch.moved){e.preventDefault();targetPan=Math.max(-200,Math.min(140,hiveTouch.pan+delta));}});
const finishHiveTouch=e=>{if(!hiveTouch||e.pointerId!==hiveTouch.id)return;suppressTileClick=hiveTouch.moved;hiveTouch=null;if(hive.hasPointerCapture(e.pointerId))hive.releasePointerCapture(e.pointerId);};
hive.addEventListener('pointerup',finishHiveTouch);hive.addEventListener('pointercancel',finishHiveTouch);hive.addEventListener('click',e=>{if(suppressTileClick){e.preventDefault();e.stopImmediatePropagation();suppressTileClick=false;}},true);
window.orbit.on(data=>{if(data.kind==='pointer'){if(Math.hypot(pointer.x-data.x,pointer.y-data.y)>1)activityAt=performance.now();if(!press)pointer={x:data.x,y:data.y};}else if(data.kind==='gesture-finished'){finishDragVisual(data);}else if(data.kind==='placement'){applyPlacement(data);}else if(data.kind==='prefs'){applyPrefs(data.prefs);}else if(data.kind==='black'){blackActive=data.value;if(data.value)endGesture(true);}else if(data.kind==='mode'){if(!data.token||data.token===gestureToken)visualMode(data.value);}else if(data.kind==='open-tool'){safe(()=>openTool(data.tool))();}else if(data.kind==='animation'){animation(data.state);}else if(data.kind==='feedback'){animation(data.state,4000);toast(data.text);}});
function frame(now){requestAnimationFrame(frame);if(!initReady)return;advanceScene(now);if(!testing)personality(now);const delta=lastFrame?now-lastFrame:16.667;lastFrame=now;if(delta>3&&delta<100){sample.push(delta);if(sample.length>360)sample.shift();}if(!testing){if(demo&&now>demoAt){animation(availableStates[demoIndex++%availableStates.length],0,true);demoAt=now+5000;}if(returnAt&&now>returnAt&&!demo){returnAt=0;avatar.select('idle');originalHeroStep=2;originalHeroAt=now+6800;}const x=Math.max(-1,Math.min(1,(pointer.x-scenePosition.x-320)/(prefs.size*2))),y=Math.max(-1,Math.min(1,-(pointer.y-scenePosition.y-320)/(prefs.size*2)));if(prefs.animate)avatar.step(Math.min(.1,delta/1000),prefs.follow?(dragging?dragLook.x:x):null,prefs.follow?(dragging?dragLook.y:y):null);if(dragging){dragLook.x*=.88;dragLook.y*=.88;}}
 if(mode==='menu'){pan+=(targetPan-pan)*Math.min(1,delta*.016);document.documentElement.style.setProperty('--pan',pan+'px');for(const e of entries){const centerDistance=Math.hypot(e.x,e.y+pan),edge=Math.abs(e.y+pan);e.b.style.setProperty('--visible',Math.min(1,Math.max(0,(centerDistance-36)/15),Math.max(0,(153-edge)/25)));e.b.style.pointerEvents=centerDistance<38||edge>152?'none':'';}}
 updateShape(now);
}
// A native region receives touch immediately, regardless of the mouse's position.
// Transparent space stays outside the region and passes through to desktop apps.
// Keep the native drawing region still throughout animations. Updating it for
// every moving icon invalidates transparent compositor surfaces on Windows.
let shapeAt=0,shapeKey='',shapeExpandedUntil=0;
function updateShape(now,force=false){
 if(dragging||dragFinishing)return;
 if(!force&&now-shapeAt<40)return;shapeAt=now;const regions=[];
 const rounded=(x,y,w,h,radius)=>{for(let sy=0;sy<h;sy+=4){const sh=Math.min(4,h-sy),dy=Math.max(0,radius-Math.min(sy+sh/2,h-sy-sh/2)),inset=Math.floor(radius-Math.sqrt(Math.max(0,radius*radius-dy*dy)));regions.push({x:x+inset,y:y+sy,width:Math.max(1,w-2*inset),height:sh});}};
 if(mode==='menu'||now<shapeExpandedUntil){rounded(160,124,320,512,44);}else{
  const center=320,radius=Math.ceil(prefs.size/2+18);rounded(center-radius,center-radius,radius*2,radius*2,radius);
  if(prefs.monitorPinned)rounded(187,222,266,76,28);
  if($('#toast').classList.contains('show'))rounded(200,472,240,40,20);
 }
 if(sceneMotion){const minX=Math.min(sceneMotion.from.x,sceneMotion.to.x),minY=Math.min(sceneMotion.from.y,sceneMotion.to.y),maxX=Math.max(sceneMotion.from.x,sceneMotion.to.x),maxY=Math.max(sceneMotion.from.y,sceneMotion.to.y);regions.splice(0,regions.length,{x:Math.floor(minX+150),y:Math.floor(minY+114),width:Math.ceil(maxX-minX+340),height:Math.ceil(maxY-minY+532)});}else for(const r of regions){r.x=Math.round(r.x+scenePosition.x);r.y=Math.round(r.y+scenePosition.y);}
 const key=JSON.stringify(regions);if(key!==shapeKey){shapeKey=key;window.orbit.send('shape',regions);}
}

window.addEventListener('error',e=>{errorCount++;window.orbit.send('renderer-error',String(e.message));});
async function init(){const data=await api('init');config=data.config;icons=data.icons;applyPrefs(data.prefs);gestureSerial=gestureToken=data.placement.token||0;applyPlacement(data.placement);buildHive();buildCards();qaMode=!!data.qa;initReady=true;requestAnimationFrame(frame);if(data.qa)setTimeout(()=>(data.qaVisualOnly?qaVisualCheck():data.qaDragOnly?qaDragCheck():qaCheck()).catch(e=>api('qa.report',{ok:false,error:e.stack})),3500);}
async function qaCheck(){testing=true;const report={states:[],gaze:{},errors:errorCount};for(const name of avatar.states){avatar.select(name);for(let i=0;i<10;i++)avatar.step(.06,.3,.2);const svg=$('#avatar svg');if(!svg||!svg.querySelector('path')||/NaN|Infinity/.test(svg.outerHTML))throw new Error('Invalid state '+name);report.states.push(name);}avatar.select('logo');for(const [name,x,y] of [['left',-1,0],['right',1,0],['up',0,1],['down',0,-1]]){for(let i=0;i<25;i++)avatar.step(1/60,x,y);report.gaze[name]=[...$('#avatar svg').querySelectorAll('path')].map(p=>p.getAttribute('d')).join('').slice(-1800);}report.gazeUnique=new Set(Object.values(report.gaze)).size;delete report.gaze;avatar.select('logo');testing=false;report.touch=await api('qa.touch');animation('logo');for(let i=0;i<100;i++)avatar.step(.03,0,0);await new Promise(r=>setTimeout(r,80));report.silhouette=await api('qa.silhouette');await setMode('menu');await new Promise(r=>setTimeout(r,1400));const rect=ball.getBoundingClientRect();report.ball={width:rect.width,height:rect.height};report.overlaps=entries.map(e=>e.b.getBoundingClientRect()).filter(r=>Math.hypot(r.left+r.width/2-rect.left-rect.width/2,r.top+r.height/2-rect.top-rect.height/2)<(r.width+rect.width)/2).length;report.border=getComputedStyle(ball).borderTopWidth;report.edges=await api('qa.edges');report.policy=await api('qa.policy');report.inlineCards=$$('.inline-card').length;report.visibleCards=$$('.inline-card').filter(c=>+getComputedStyle(c).opacity>.1).length;report.system=await api('system.status');report.uniformIcons=new Set(entries.map(e=>Math.round(e.b.getBoundingClientRect().width))).size===1;report.quickSliders=$$('#quick .quick-bar:not([hidden]) input[type=range]').length;report.micCompact=$$('#quick-microphone').length===1&&!$('#quick-input');report.brightnessQuick=!!$('#quick-brightness-range');report.nativeSelects=$$('select').length;report.missingIcons=$$('img').filter(i=>!i.complete||!i.naturalWidth).map(i=>i.getAttribute('src'));report.black=await api('qa.black');report.transparentGaps=!document.elementFromPoint(15,15)?.closest('.hit');await api('qa.capture',{name:'menu'});const savedTheme={...prefs};applyPrefs({...prefs,theme:'light',glass:.7,opacity:.85,highlight:.25});await new Promise(r=>setTimeout(r,120));await api('qa.capture',{name:'light'});applyPrefs(savedTheme);await api('qa.capture',{name:'preview',rect:{x:0,y:0,width:640,height:640}});await api('qa.capture',{name:'quick-audio'});report.nightSwitch=!$('#quick-night')&&!$('#night-strength')&&$('#quick-brightness').lastElementChild.id==='quick-night-button'&&$('#quick-night-button').getAttribute('role')==='switch'&&$('#quick-night-button').getAttribute('aria-checked')===String(nightState.enabled);const fits=el=>{const r=el.getBoundingClientRect();return +getComputedStyle(el).opacity>.9&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;};entries.find(e=>e.b.getAttribute('aria-label')==='音频').b.click();await new Promise(r=>setTimeout(r,450));report.audioCard=fits($('#card-audio'))&&!!$('#card-audio input[type=range]')&&$$('#card-audio .audio-card-device').length>0;await api('qa.capture',{name:'audio-card'});entries.find(e=>e.b.getAttribute('aria-label')==='麦克风').b.click();await new Promise(r=>setTimeout(r,450));report.micCard=fits($('#card-mic'))&&!$('#card-mic input[type=range]')&&!!$('#card-mic [role=switch]')&&$$('#card-mic .audio-card-device').length>0;await api('qa.capture',{name:'mic-card'});entries.find(e=>e.b.getAttribute('aria-label')==='麦克风').b.click();await new Promise(r=>setTimeout(r,100));report.audioCardToggle=activeCard===''&&!scene.classList.contains('has-control-card');await openTool('settings');await new Promise(r=>setTimeout(r,900));report.settingsVisible=fits($('#card-settings'));await api('qa.capture',{name:'settings'});await showWifi();await new Promise(r=>setTimeout(r,900));report.wifiVisible=fits($('#card-wifi'));report.wifiRows=$$('#card-wifi .network-row').length;await api('qa.capture',{name:'wifi'});await showBluetooth();await new Promise(r=>setTimeout(r,900));report.bluetoothVisible=fits($('#card-bluetooth'));report.bluetoothRows=$$('#card-bluetooth .network-row').length;await api('qa.capture',{name:'bluetooth'});hideControlCard();clearInterval(wifiTimer);clearInterval(bluetoothTimer);const sorted=sample.slice().sort((a,b)=>a-b);report.medianFrameMs=sorted[Math.floor(sorted.length/2)];report.fps=1000/report.medianFrameMs;report.p95FrameMs=sorted[Math.floor(sorted.length*.95)];report.errors=errorCount;report.ok=report.audioCard&&report.micCard&&report.audioCardToggle&&report.states.length===53&&report.gazeUnique===4&&report.overlaps===0&&report.border==='0px'&&report.errors===0&&report.medianFrameMs<22&&report.edges.ok&&report.transparentGaps&&report.uniformIcons&&report.settingsVisible&&report.wifiVisible&&report.bluetoothVisible&&report.quickSliders===2&&report.micCompact&&report.brightnessQuick&&report.nightSwitch&&report.missingIcons.length===0&&report.nativeSelects===0&&report.black.ok&&report.touch.ok&&report.silhouette.ok&&report.inlineCards>=8&&report.visibleCards===1&&Object.values(report.policy).every(Boolean)&&Number.isFinite(report.system.cpu);await api('qa.report',report);await setMode('menu');}
init().catch(e=>{toast(e.message);});

window.addEventListener('blur',()=>endGesture(true));

matchMedia('(prefers-color-scheme:dark)').addEventListener('change',()=>{if(!prefs.theme||prefs.theme==='system')applyPrefs(prefs);});

let qaMode=false,activityAt=performance.now(),originalHeroStep=0,originalHeroAt=0;
// x.ai/bot hero: waking once, then idle / happy / idle / curious.
const originalHeroSequence=[['waking',2200],['idle',6800],['happy',3200],['idle',7400],['curious',3600]];
function personality(now){
 if(qaMode||prefs.autoExpressions===false||!prefs.animate||demo||dragging||dragFinishing||press||returnAt||now<originalHeroAt)return;
 const [name,duration]=originalHeroSequence[originalHeroStep];if(avatar.state!==name)animation(name);originalHeroAt=now+duration;originalHeroStep=originalHeroStep+1<originalHeroSequence.length?originalHeroStep+1:1;
}
ball.addEventListener('click',e=>{if(e.detail===0&&!press)safe(()=>setMode(mode==='closed'?'menu':'closed'))();});

let audioCardRequest=0;
async function showAudioCard(flow){
 const id=flow?'card-mic':'card-audio';
 if(activeCard===id){hideControlCard();return;}
 await openTool(id);
 const request=++audioCardRequest,body=$('#'+id+' .card-body');body.textContent='读取设备…';
 try{
  const list=(await api('audio.list',{flow})).sort((a,b)=>Number(b.isDefault)-Number(a.isDefault));
  if(request!==audioCardRequest||activeCard!==id)return;
  body.replaceChildren();
  if(!list.length){body.textContent='无可用设备';return;}
  let device=list.find(d=>d.isDefault)||list[0];
  const controls=document.createElement('div');controls.className='audio-card-controls';
  const mute=iconButton(flow?'mic':'volume-2',flow?'麦克风开关':'输出静音',async()=>{
   const target=device,muted=!target.muted;mute.disabled=true;
   try{await api('audio.mute',{id:target.id,value:muted});target.muted=muted;sync();await refreshQuick();}finally{mute.disabled=false;}
  });
  mute.setAttribute('role',flow?'switch':'button');controls.appendChild(mute);
  let range,number;
  if(!flow){
   range=document.createElement('input');range.type='range';range.min=0;range.max=100;range.className='slider';range.setAttribute('aria-label','输出音量');
   number=document.createElement('span');number.className='audio-card-level';controls.append(range,number);
   let timer;
   range.oninput=()=>{device.level=+range.value/100;sync();clearTimeout(timer);const target=device.id,value=device.level;timer=setTimeout(()=>safe(()=>api('audio.level',{id:target,value}))(),20);};
   range.onchange=safe(async()=>{clearTimeout(timer);await api('audio.level',{id:device.id,value:device.level});await refreshQuick();});
  }else{const label=document.createElement('span');label.className='audio-card-state';controls.appendChild(label);}
  const sync=()=>{
   mute.classList.toggle('muted',device.muted);
   if(flow){mute.setAttribute('aria-checked',String(!device.muted));controls.lastChild.textContent=device.muted?'已关闭':'已开启';}
   else{mute.setAttribute('aria-pressed',String(device.muted));range.value=Math.round(device.level*100);range.style.setProperty('--value',range.value+'%');number.textContent=range.value+'%';}
  };sync();body.appendChild(controls);
  const devices=document.createElement('div');devices.className='audio-card-devices';devices.setAttribute('role','group');devices.setAttribute('aria-label',flow?'选择输入源':'选择输出设备');
  for(const d of list){
   const b=button(d.name,async()=>{
    b.disabled=true;
    try{await api('audio.default',{id:d.id});device=d;for(const option of devices.children){const selected=option===b;option.classList.toggle('selected',selected);option.setAttribute('aria-pressed',String(selected));}sync();await refreshQuick();await refreshAudioChoices();}finally{b.disabled=false;}
   },'audio-card-device');b.dataset.device=d.id;b.classList.toggle('selected',d===device);b.setAttribute('aria-pressed',String(d===device));devices.appendChild(b);
  }
  body.appendChild(devices);
 }catch(e){if(request===audioCardRequest&&activeCard===id)body.textContent=e.message;}
}

async function showDevices(flow){
 const card=$('#card-devices'),body=card.querySelector('.card-body');card.querySelector('h2').textContent=flow?'输入设备':'输出设备';body.replaceChildren();
 const list=await api('audio.list',{flow});for(const d of list){const b=button(d.name,async()=>{await api('audio.default',{id:d.id});for(const e of body.children)e.classList.remove('selected');b.classList.add('selected');await refreshQuick();},'action device-option');b.classList.toggle('selected',d.isDefault);body.appendChild(b);}
 if(!list.length){const empty=document.createElement('span');empty.textContent='无可用设备';body.appendChild(empty);}await openTool('card-devices');
}

async function refreshAudioChoices(){for(const [flow,id]of [[0,'output-choice'],[1,'input-choice']]){const list=await api('audio.list',{flow}),field=$('#'+id);field.setItems(list.map(d=>[d.id,d.name]));field.value=list.find(d=>d.isDefault)?.id||list[0]?.id;}}
let wifiTimer,bluetoothTimer;
function deviceRow(name,detail){const row=document.createElement('div');row.className='network-row';const copy=document.createElement('div'),title=document.createElement('strong'),status=document.createElement('span');copy.className='network-copy';title.textContent=name;status.textContent=detail;copy.append(title,status);row.appendChild(copy);return row;}
function radioActions(body,kind,refresh){const bar=document.createElement('div');bar.className='radio-actions';const state=radioData.find(r=>r.kind===kind)?.state;bar.append(button(state==='On'?'关闭':'开启',async()=>{await toggleRadio(kind);await refresh(false);}),iconButton('refresh-cw','刷新设备',()=>refresh(true)));body.appendChild(bar);}
async function showWifi(){if(activeCard==='card-wifi'){hideControlCard();clearInterval(wifiTimer);return;}await openTool('card-wifi');await refreshWifi();clearInterval(wifiTimer);wifiTimer=setInterval(()=>{if(activeCard==='card-wifi'&&mode==='menu')refreshWifi(true).catch(()=>{});else clearInterval(wifiTimer);},5000);}
async function refreshWifi(quiet=false){const body=$('#card-wifi .card-body'),previousScroll=body.scrollTop;if(!quiet){body.textContent='正在扫描…';await updateRadios();}let list;try{list=await api('wifi.list',{scan:!quiet});}catch(e){body.textContent=e.message;radioActions(body,'WiFi',()=>refreshWifi(false));return;}if(document.activeElement?.matches('#card-wifi input'))return;body.replaceChildren();radioActions(body,'WiFi',()=>refreshWifi(false));const seen=new Set();for(const n of list.sort((a,b)=>(+b.connected-+a.connected)||b.signal-a.signal)){const key=n.adapter+'|'+n.hex;if(seen.has(key))continue;seen.add(key);const row=deviceRow(n.name,(n.connected?'已连接 · ':n.known?'已保存 · ':'')+n.signal+'%'+(n.secure?' · 加密':''));const action=button(n.connected?'断开':'连接',async()=>{if(n.connected){await api('wifi.disconnect',{adapter:n.adapter});await refreshWifi();return;}if(!n.known&&n.secure&&![4,7,9].includes(n.auth)){row.querySelector('.network-copy span').textContent='需要已有的企业网络配置';return;}if(!n.known&&n.secure){const form=document.createElement('div');form.className='network-password';const input=document.createElement('input');input.type='password';input.placeholder='Wi-Fi 密码';input.className='path-input';input.setAttribute('aria-label',n.name+' 密码');const join=button('连接',async()=>{await api('wifi.connect',{...n,password:input.value});input.value='';row.querySelector('.network-copy span').textContent='正在连接…';form.remove();setTimeout(()=>refreshWifi(true),1500);});form.append(input,join);row.replaceChildren(row.firstChild,form);input.focus();return;}await api('wifi.connect',{...n,password:''});row.querySelector('.network-copy span').textContent='正在连接…';setTimeout(()=>refreshWifi(true),1500);});row.appendChild(action);body.appendChild(row);}if(!seen.size){const empty=document.createElement('div');empty.className='empty';empty.textContent='未发现网络';body.appendChild(empty);}body.scrollTop=previousScroll;}
async function showBluetooth(){if(activeCard==='card-bluetooth'){hideControlCard();clearInterval(bluetoothTimer);return;}await openTool('card-bluetooth');await refreshBluetooth(false);clearInterval(bluetoothTimer);bluetoothTimer=setInterval(()=>{if(activeCard==='card-bluetooth'&&mode==='menu')refreshBluetoothPairing().catch(()=>{});else clearInterval(bluetoothTimer);},600);}
async function refreshBluetooth(discover=false){const body=$('#card-bluetooth .card-body');body.textContent=discover?'正在搜索附近设备…':'正在读取设备…';await updateRadios();let list;try{list=await api('bluetooth.list',{discover});}catch(e){body.textContent=e.message;return;}body.replaceChildren();pairingKey='';radioActions(body,'Bluetooth',refreshBluetooth);const pairing=document.createElement('div');pairing.id='bluetooth-pairing';body.appendChild(pairing);for(const d of list.sort((a,b)=>(+b.connected-+a.connected)||(+b.paired-+a.paired))){const row=deviceRow(d.name,d.connected?'已连接':d.paired?'已配对':'附近设备');if(d.paired){row.appendChild(button(d.connected?'断开':'连接',async()=>{await api('bluetooth.connection',{id:d.id,enabled:!d.connected});row.querySelector('.network-copy span').textContent=d.connected?'正在断开…':'正在连接…';setTimeout(()=>refreshBluetooth(false),1800);}));const remove=button('移除',async()=>{if(remove.dataset.confirm!=='yes'){remove.dataset.confirm='yes';remove.textContent='确认移除';return;}await api('bluetooth.remove',{id:d.id});await refreshBluetooth(false);},'device-remove');row.appendChild(remove);}else row.appendChild(button('配对',async()=>{await api('bluetooth.pair',{id:d.id});row.querySelector('.network-copy span').textContent='正在配对…';}));body.appendChild(row);}if(!list.length){const text=document.createElement('div');text.className='empty';text.textContent='未发现设备，点刷新搜索';body.appendChild(text);}await refreshBluetoothPairing();}
let pairingKey='';async function refreshBluetoothPairing(){const host=$('#bluetooth-pairing');if(!host)return;const p=await api('bluetooth.status');const key=JSON.stringify(p);if(key===pairingKey)return;pairingKey=key;host.replaceChildren();if(p.state==='idle')return;const text=document.createElement('div');text.className='pairing-message';text.textContent=(p.name?p.name+' · ':'')+p.message;host.appendChild(text);if(p.state==='confirm'){if(p.kind==='pin'){const pin=document.createElement('input');pin.className='path-input';pin.type='text';pin.maxLength=16;pin.placeholder='配对码';pin.setAttribute('aria-label','蓝牙配对码');host.appendChild(pin);}else{const code=document.createElement('strong');code.className='pairing-code';code.textContent=p.code;host.appendChild(code);}const controls=document.createElement('div');controls.className='card-row';controls.append(button('确认',async()=>{await api('bluetooth.reply',{accept:true,pin:host.querySelector('input')?.value||''});}),button('取消',()=>api('bluetooth.reply',{accept:false})));host.appendChild(controls);}}


async function qaDragCheck(){const touch=await api('qa.touch');await api('qa.report',{ok:touch.ok&&errorCount===0,errors:errorCount,touch});}

async function qaVisualCheck(){
 const saved={...prefs};const report={};
 await setMode('menu');await new Promise(r=>setTimeout(r,1300));
 const rects=entries.map(e=>e.b.getBoundingClientRect()),center=ball.getBoundingClientRect();
 report.uniformTiles=new Set(rects.map(r=>Math.round(r.width))).size===1;
 report.noOrbOverlap=rects.every(r=>Math.hypot(r.x+r.width/2-center.x-center.width/2,r.y+r.height/2-center.y-center.height/2)>=(r.width+center.width)/2);
 report.noTileOverlap=rects.every((a,i)=>rects.every((b,j)=>i===j||Math.hypot(a.x-b.x,a.y-b.y)>=a.width+6));
 report.uniformGlyphs=new Set($$('.tile img').map(i=>Math.round(i.getBoundingClientRect().width))).size===1;
 report.vectorEdge=!!$('.tile[aria-label="Edge"] img');
 report.missingIcons=$$('img').filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src);
 report.noBackdrop=getComputedStyle($('.tile')).backdropFilter==='none';
 await api('qa.capture',{name:'redesign'});
 await openTool('WeChat');await new Promise(r=>setTimeout(r,800));
 report.activeCard=$('.tile[aria-label="微信"]').classList.contains('is-active');
 await api('qa.capture',{name:'redesign-card'});hideControlCard();await new Promise(r=>setTimeout(r,400));
 applyPrefs({...prefs,theme:'light'});await new Promise(r=>setTimeout(r,500));await api('qa.capture',{name:'redesign-light'});applyPrefs(saved);
 report.presets=await qaPresetCheck();report.errors=errorCount;report.ok=report.presets.ok&&report.uniformTiles&&report.noOrbOverlap&&report.noTileOverlap&&report.uniformGlyphs&&report.vectorEdge&&report.noBackdrop&&report.activeCard&&!report.missingIcons.length&&!report.errors;
 await api('qa.report',report);await setMode('menu');
}

async function qaPresetCheck(){
 const saved={...prefs},report={layouts:{},palettes:{},reveals:{}};
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 try{
  for(const [layout] of orbitLayouts){await changePrefs({layout});await wait(650);const rs=entries.map(e=>e.b.getBoundingClientRect()),b=ball.getBoundingClientRect();report.layouts[layout]=rs.every((a,i)=>Math.hypot(a.x+a.width/2-b.x-b.width/2,a.y+a.height/2-b.y-b.height/2)>=(a.width+b.width)/2&&rs.every((c,j)=>i===j||Math.hypot(a.x-c.x,a.y-c.y)>=a.width));await api('qa.capture',{name:'layout-'+layout});}
  for(const [palette] of orbitPalettes){await changePrefs({palette});await wait(100);report.palettes[palette]=document.documentElement.dataset.palette===palette&&entries.every(e=>/^\d+,\d+,\d+$/.test(e.b.style.getPropertyValue('--rgb')));}
  for(const [reveal] of orbitReveals){await changePrefs({reveal});await setMode('closed');await wait(120);await setMode('menu');await wait(900);report.reveals[reveal]=entries.every(e=>+getComputedStyle(e.b).opacity>.9);}
  await openTool('settings');await wait(400);selectSettingsPage('layout');$('.preset-choice[data-pref="layout"][data-value="ring"]').click();await wait(700);$('.preset-choice[data-pref="palette"][data-value="ocean"]').click();await wait(300);
  const data=await api('init');report.persists=data.prefs.layout==='ring'&&data.prefs.palette==='ocean';report.selection=$('.preset-choice[data-pref="layout"][data-value="ring"]').getAttribute('aria-pressed')==='true'&&$('.preset-choice[data-pref="palette"][data-value="ocean"]').getAttribute('aria-pressed')==='true';await api('qa.capture',{name:'appearance-options'});
  const bounds=$('#card-settings .card-body').getBoundingClientRect();report.choicesVisible=$$('.preset-choice[data-pref=palette],.preset-choice[data-pref=layout]').every(b=>{const r=b.getBoundingClientRect();return r.top>=bounds.top&&r.bottom<=bounds.bottom;});report.styles=await qaSurfaceCheck();report.ok=report.styles.ok&&report.choicesVisible&&report.persists&&report.selection&&Object.values(report.layouts).every(Boolean)&&Object.values(report.palettes).every(Boolean)&&Object.values(report.reveals).every(Boolean);
  return report;
 }finally{hideControlCard();await changePrefs(saved);await wait(200);}
}

async function qaSurfaceCheck(){
 const signatures={tiles:new Set(),monitor:new Set(),quick:new Set(),card:new Set()},materials={};
 const wait=ms=>new Promise(r=>setTimeout(r,ms));
 const signature=el=>{const c=getComputedStyle(el);return [c.backgroundImage,c.backgroundColor,c.borderColor,c.boxShadow,c.borderRadius].join('|');};
 hideControlCard();
 for(const [surface] of orbitSurfaces){
  await changePrefs({surface,theme:'dark'});await wait(250);
  for(const [key,el]of [['tiles',entries[0].b],['monitor',$('#card-monitor')],['quick',$('#quick-output')],['card',$('#card-mic')]])signatures[key].add(signature(el));
  materials[surface]=[entries[0].b,$('#card-monitor'),$('#quick-output'),$('#card-mic')].every(el=>getComputedStyle(el).backdropFilter==='none');
  await api('qa.capture',{name:'style-'+surface});
 }
 const matchesTop=el=>{const a=$('#card-monitor').getBoundingClientRect(),b=el.getBoundingClientRect();return Math.abs(a.left-b.left)<1&&Math.abs(a.right-b.right)<1;};
 let aligned=matchesTop($('#quick'));
 await showAudioCard(1);await wait(350);aligned=aligned&&matchesTop($('#card-mic'));
 await openTool('settings');await wait(350);aligned=aligned&&matchesTop($('#card-settings'));hideControlCard();
 const palettes={};
 for(const [palette]of orbitPalettes){
  await changePrefs({palette});await wait(100);
  const accent=getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
  palettes[palette]=[$('#card-monitor'),$('#quick-output'),$('#card-mic')].every(el=>getComputedStyle(el).getPropertyValue('--material-rgb').trim()===accent);
 }
 await changePrefs({surface:'classic',glass:0,opacity:.95,highlight:.1});await wait(100);
 const elements=[entries[0].b,$('#card-monitor'),$('#quick-output'),$('#card-mic')],before=elements.map(signature);
 await changePrefs({glass:.8,opacity:.6,highlight:.5});await wait(100);
 const controlsLinked=elements.every((el,i)=>signature(el)!==before[i]);
 await changePrefs({glass:prefs.glass,opacity:prefs.opacity,highlight:prefs.highlight,palette:'original'});
 for(const surface of ['liquid','neon']){
  await changePrefs({surface,theme:'light'});await wait(250);await api('qa.capture',{name:'style-'+surface+'-light'});
 }
 await changePrefs({theme:'dark',glass:.2,opacity:.85,highlight:.15,surface:'liquid'});
 await showAudioCard(0);await wait(500);await api('qa.capture',{name:'linked-audio-card'});
 await showAudioCard(1);await wait(500);await api('qa.capture',{name:'linked-mic-card'});hideControlCard();
 await openTool('settings');selectSettingsPage('style');await wait(300);$('.preset-choice[data-pref="surface"][data-value="liquid"]').click();await wait(300);
 const saved=await api('init'),body=$('#card-settings .card-body').getBoundingClientRect();
 const visible=$$('.preset-choice[data-pref=surface]').every(b=>{const r=b.getBoundingClientRect();return r.top>=body.top&&r.bottom<=body.bottom;});
 await api('qa.capture',{name:'style-picker'});
 const distinct=Object.fromEntries(Object.entries(signatures).map(([k,v])=>[k,v.size]));
 return {materials,distinct,aligned,palettes,controlsLinked,visible,persisted:saved.prefs.surface==='liquid',ok:Object.values(materials).every(Boolean)&&Object.values(distinct).every(n=>n===6)&&Object.values(palettes).every(Boolean)&&aligned&&controlsLinked&&visible&&saved.prefs.surface==='liquid'};
}
