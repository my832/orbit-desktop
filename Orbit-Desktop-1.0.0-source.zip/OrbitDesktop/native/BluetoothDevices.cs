﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

static class BluetoothDevices {
 [StructLayout(LayoutKind.Sequential)]struct TIME{public ushort Year,Month,DayOfWeek,Day,Hour,Minute,Second,Milliseconds;}
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct DEVICE{public uint size;public ulong address;public uint deviceClass;public int connected,remembered,authenticated;public TIME lastSeen,lastUsed;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=248)]public string name;}
 [StructLayout(LayoutKind.Sequential)]struct SEARCH{public uint size;public int authenticated,remembered,unknown,connected,inquiry;public byte timeout;public IntPtr radio;}
 [StructLayout(LayoutKind.Sequential)]struct RADIO{public uint size;}
 [StructLayout(LayoutKind.Sequential)]struct REQUEST{public DEVICE device;public int method,capability,requirements;public uint number;}
 [UnmanagedFunctionPointer(CallingConvention.Winapi)]delegate bool AuthCallback(IntPtr context,ref REQUEST request);
 static readonly object gate=new object();static Dictionary<string,object> status=new Dictionary<string,object>{{"state","idle"}};static bool pairing;static AutoResetEvent reply=new AutoResetEvent(false);static bool accepted;static string pin="";static AuthCallback callback;
 static DEVICE Info(ulong address){return new DEVICE{size=(uint)Marshal.SizeOf(typeof(DEVICE)),address=address};}
 static IntPtr Radio(){var p=new RADIO{size=4};IntPtr radio;IntPtr find=BluetoothFindFirstRadio(ref p,out radio);if(find==IntPtr.Zero)throw new Exception("蓝牙适配器不可用");BluetoothFindRadioClose(find);return radio;}
 public static object List(bool discover){var results=new List<object>();var p=new SEARCH{size=(uint)Marshal.SizeOf(typeof(SEARCH)),authenticated=1,remembered=1,unknown=1,connected=1,inquiry=discover?1:0,timeout=2};var d=Info(0);IntPtr search=BluetoothFindFirstDevice(ref p,ref d);if(search==IntPtr.Zero)return results;try{do{results.Add(new{id=d.address.ToString("X12"),name=String.IsNullOrEmpty(d.name)?"蓝牙设备":d.name,connected=d.connected!=0,paired=d.authenticated!=0||d.remembered!=0});d=Info(0);}while(BluetoothFindNextDevice(search,ref d));}finally{BluetoothFindDeviceClose(search);}return results;}
 public static object Status(){lock(gate)return new Dictionary<string,object>(status);}
 static void Set(string state,string name,string message,string kind="",string code=""){lock(gate)status=new Dictionary<string,object>{{"state",state},{"name",name},{"message",message},{"kind",kind},{"code",code}};}
 public static object Pair(string address){ulong id=Convert.ToUInt64(address,16);lock(gate){if(pairing)throw new Exception("正在配对另一台设备");pairing=true;}var worker=new Thread(()=>PairWorker(id));worker.IsBackground=true;worker.Start();return true;}
 static void PairWorker(ulong address){IntPtr radio=IntPtr.Zero,registration=IntPtr.Zero;string name="蓝牙设备";try{radio=Radio();var d=Info(address);if(BluetoothGetDeviceInfo(radio,ref d)!=0)throw new Exception("设备已离开范围，请刷新");name=d.name;Set("pairing",name,"正在配对");
  callback=(IntPtr context,ref REQUEST request)=>{try{var r=request;string kind=r.method==1?"pin":r.method==4?"display":"confirm";if(r.method!=1&&r.method!=3&&r.method!=4){Set("failed",r.device.name,"此设备的配对方式暂不支持");return true;}accepted=false;pin="";reply.Reset();Set("confirm",r.device.name,kind=="pin"?"输入设备配对码":kind=="display"?"在设备上输入此码":"确认设备上的配对码",kind,r.number.ToString("D6"));bool timely=reply.WaitOne(60000);IntPtr response=Marshal.AllocHGlobal(48);try{for(int i=0;i<48;i++)Marshal.WriteByte(response,i,0);Marshal.WriteInt64(response,0,unchecked((long)r.device.address));Marshal.WriteInt32(response,8,r.method);bool allow=timely&&accepted;if(r.method==1){byte[] code=Encoding.UTF8.GetBytes(pin);allow=allow&&code.Length>0&&code.Length<=16;for(int i=0;i<Math.Min(16,code.Length);i++)Marshal.WriteByte(response,12+i,code[i]);Marshal.WriteByte(response,28,(byte)Math.Min(16,code.Length));}else Marshal.WriteInt32(response,12,(int)r.number);Marshal.WriteByte(response,44,(byte)(allow?0:1));BluetoothSendAuthenticationResponseEx(radio,response);}finally{Marshal.FreeHGlobal(response);}Set("pairing",r.device.name,"正在完成配对");return true;}catch{return true;}};
  if(BluetoothRegisterForAuthenticationEx(ref d,out registration,callback,IntPtr.Zero)!=0)throw new Exception("无法准备配对验证");uint codeResult=BluetoothAuthenticateDeviceEx(IntPtr.Zero,radio,ref d,IntPtr.Zero,4);Set(codeResult==0?"paired":"failed",name,codeResult==0?"已配对":"配对未完成，请确认设备处于配对模式");
 }catch(Exception e){Set("failed",name,e.Message);}finally{if(registration!=IntPtr.Zero)BluetoothUnregisterAuthentication(registration);if(radio!=IntPtr.Zero)CloseHandle(radio);callback=null;lock(gate)pairing=false;}}
 public static object Reply(bool allow,string value){accepted=allow;pin=value??"";reply.Set();return true;}
 public static object Remove(string address){ulong id=Convert.ToUInt64(address,16);if(BluetoothRemoveDevice(ref id)!=0)throw new Exception("无法移除蓝牙设备");return true;}
 public static object Connection(string address,bool enable){IntPtr radio=Radio();try{var d=Info(Convert.ToUInt64(address,16));if(BluetoothGetDeviceInfo(radio,ref d)!=0)throw new Exception("蓝牙设备不可用");uint count=32;IntPtr data=Marshal.AllocHGlobal(16*32);try{if(BluetoothEnumerateInstalledServices(radio,ref d,ref count,data)!=0||count==0)throw new Exception("此设备没有可直接连接的服务");int changed=0;for(int i=0;i<Math.Min(count,32);i++){Guid service=(Guid)Marshal.PtrToStructure(IntPtr.Add(data,i*16),typeof(Guid));if(BluetoothSetServiceState(radio,ref d,ref service,enable?1u:0u)==0)changed++;}if(changed==0)throw new Exception("Windows 未接受连接请求");return true;}finally{Marshal.FreeHGlobal(data);}}finally{CloseHandle(radio);}}
 [DllImport("bthprops.cpl")]static extern IntPtr BluetoothFindFirstRadio(ref RADIO p,out IntPtr radio);
 [DllImport("bthprops.cpl")]static extern bool BluetoothFindRadioClose(IntPtr h);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern IntPtr BluetoothFindFirstDevice(ref SEARCH p,ref DEVICE d);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern bool BluetoothFindNextDevice(IntPtr h,ref DEVICE d);
 [DllImport("bthprops.cpl")]static extern bool BluetoothFindDeviceClose(IntPtr h);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern uint BluetoothGetDeviceInfo(IntPtr radio,ref DEVICE d);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern uint BluetoothRegisterForAuthenticationEx(ref DEVICE d,out IntPtr registration,AuthCallback callback,IntPtr context);
 [DllImport("bthprops.cpl")]static extern bool BluetoothUnregisterAuthentication(IntPtr registration);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern uint BluetoothAuthenticateDeviceEx(IntPtr parent,IntPtr radio,ref DEVICE d,IntPtr oob,int requirements);
 [DllImport("bthprops.cpl")]static extern uint BluetoothSendAuthenticationResponseEx(IntPtr radio,IntPtr response);
 [DllImport("bthprops.cpl")]static extern uint BluetoothRemoveDevice(ref ulong address);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern uint BluetoothEnumerateInstalledServices(IntPtr radio,ref DEVICE d,ref uint count,IntPtr guids);
 [DllImport("bthprops.cpl",CharSet=CharSet.Unicode)]static extern uint BluetoothSetServiceState(IntPtr radio,ref DEVICE d,ref Guid service,uint flags);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr h);
}
