# Orbit Desktop

Windows 桌面悬浮球：围绕小球展开应用入口、系统控制和简洁监控。

![展开界面](docs/preview.png)

## 下载和使用

Windows 10/11 x64。选择 Release 中的 `Orbit-Desktop-1.0.0-Setup-x64.exe` 安装；也可解压 `Orbit-Desktop-1.0.0-win-x64.zip`，运行 `Orbit Desktop.exe`。两种包均包含运行环境，不需要另装 Node.js。

安装到当前用户目录，不要求管理员权限。首次运行不开启自启；可在设置 → 控制里选择。卸载保留用户配置。

- 点小球展开或收拢；鼠标、触屏、笔均可拖动。
- Ctrl + Alt + Space 切换展开状态；右键小球或托盘进入设置、后台或退出。
- 默认应用为微信与 Edge，支持打开、最小化、置顶、正常关闭。优先自动检测，找不到时点击“选择程序”。微信不是 Windows 预装程序，未安装时不会自动下载。
- 文件管理入口打开文件资源管理器。
- 音频和麦克风直接展开小卡片；麦克风仅开关、输入源。下方两条快捷栏为音量、亮度，末尾分别提供麦克风静音和夜间模式开关。
- 黑屏覆盖全部显示器并隐藏球体，Esc 或空格退出；此功能不让计算机进入睡眠。
- Wi-Fi、蓝牙、外观与应用设置在同一组卡片中展开。
- 六种材质、六套配色、三种排列、三种展开动效。上下卡片和中间图标同步变化，面板左右对齐。

配置独立保存在 `%APPDATA%\OrbitDesktop` 与 `%LOCALAPPDATA%\OrbitDesktop`；不包含制作者的程序路径、校园网脚本、账号或设备列表。不上传遥测数据；连接 Wi-Fi、发现蓝牙等操作由 Windows 执行。

## 从源码构建

需要 Windows x64、Node.js 24 或更新的兼容版本，以及 Windows 自带的 .NET Framework 4.x 编译器。PowerShell 中运行：

```powershell
npm ci
npm run dist
```

安装包和免安装 ZIP 出现在 `dist/`。`npm run pack` 仅生成解包目录；`npm start` 启动开发版。调试原生桥前先执行 `npm run build:native`。

## GitHub 发布

将这个目录作为仓库根目录；不要提交 `node_modules`、`dist` 或个人配置。可将本地生成的 EXE、免安装 ZIP 和 `SHA256SUMS.txt` 上传到 GitHub Release。源码另提供 `Orbit-Desktop-1.0.0-source.zip`。

工作流支持手动构建和 `v*` 标签构建：手动构建只上传 Actions 构件；推送版本标签时创建附带文件的 **草稿 Release**，由仓库维护者检查后发布。项目不会自动连接 GitHub 账户或创建仓库。

**素材授权：** 为保持动画完全相同，包中保留了官网取得的球体引擎。其公开再分发授权尚未提供，不能因为本项目自有代码采用 MIT 就认定该动画也适用 MIT。公开上传含这些素材的仓库或安装包前，请先处理 [第三方授权说明](THIRD_PARTY_NOTICES.md)。

## 限制

本地构建没有代码签名证书，因此不是已签名安装包。夜间模式依赖 Windows 系统内部组件，亮度与功耗读数取决于硬件支持；没有功率接口时显示“—”。蓝牙主要覆盖经典设备，企业 Wi-Fi 需要系统已有的企业配置。

详细验证范围见 [TESTING.md](TESTING.md)，版本说明见 [CHANGELOG.md](CHANGELOG.md)。
