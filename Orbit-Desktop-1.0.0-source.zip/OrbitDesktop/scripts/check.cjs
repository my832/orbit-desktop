const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),cp=require('node:child_process');
const root=path.join(__dirname,'..');let count=0;
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);}
for(const file of walk(path.join(root,'app'))){
 if(/\.(js|cjs)$/.test(file)){cp.execFileSync(process.execPath,['--check',file]);count++;}
 if(/\.(js|cjs|json|ps1|html|css)$/.test(file)&&!file.endsWith('character.js')){
  const text=fs.readFileSync(file,'utf8');assert(!/C:[\\/]Users[\\/]|18074|连接校园网|OpenAI\.Codex|config\.Campus|api\('campus'/.test(text),`Personal data in ${file}`);
 }
}
const renderer=fs.readFileSync(path.join(root,'app/renderer.js'),'utf8');assert(renderer.includes("['微信','wechat'"));assert(renderer.includes("api('explorer')"));
for(const match of renderer.matchAll(/image\('([^']+)'\)/g)){assert(fs.existsSync(path.join(root,'app/icons',match[1]+'.svg')),match[1]);}
assert(fs.existsSync(path.join(root,'app/native/OrbitBridge.exe')));assert(!fs.existsSync(path.join(root,'app/desktop.json')));
console.log(`Checked ${count} JavaScript files, native bridge, icons and distribution privacy.`);
