using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace OrbitBall {
public class AudioDevice {
 public string Id, Name; public int Flow; public override string ToString(){return Name;}
}
public static class Audio {
 static Guid VolumeId = new Guid("5CDF2C82-841E-4546-9722-0CF74078229A");
 static void Check(int hr){Marshal.ThrowExceptionForHR(hr);}
 public static List<AudioDevice> Devices(int flow){
  var result=new List<AudioDevice>(); var en=(IEnum)new MMEnum(); ICollection col=null;
  try {Check(en.EnumAudioEndpoints(flow,1,out col)); uint count; Check(col.GetCount(out count));
   for(uint i=0;i<count;i++){IDevice d=null; IStore store=null;
    try {Check(col.Item(i,out d)); string id; Check(d.GetId(out id)); Check(d.OpenPropertyStore(0,out store));
     var key=new Key{fmtid=new Guid("a45c254e-df1c-4efd-8020-67d146a850e0"),pid=14}; Prop p;
     Check(store.GetValue(ref key,out p)); string name=p.vt==31?Marshal.PtrToStringUni(p.ptr):"音频设备"; Clear(ref p);
     result.Add(new AudioDevice{Id=id,Name=name,Flow=flow});
    }finally{Release(store);Release(d);}
   }
  }finally{Release(col);Release(en);} return result;
 }
 public static string Default(int flow){var en=(IEnum)new MMEnum();IDevice d=null;try{Check(en.GetDefaultAudioEndpoint(flow,1,out d));string id;Check(d.GetId(out id));return id;}finally{Release(d);Release(en);}}
 public static T With<T>(string id,Func<IVolume,T> action){var en=(IEnum)new MMEnum();IDevice d=null;object obj=null;try{Check(en.GetDevice(id,out d));var iid=VolumeId;Check(d.Activate(ref iid,23,IntPtr.Zero,out obj));return action((IVolume)obj);}finally{Release(obj);Release(d);Release(en);}}
 public static float Level(string id){return With(id,delegate(IVolume v){float f;Check(v.GetMasterVolumeLevelScalar(out f));return f;});}
 public static bool Muted(string id){return With(id,delegate(IVolume v){bool m;Check(v.GetMute(out m));return m;});}
 public static void SetLevel(string id,float f){With(id,delegate(IVolume v){var g=Guid.Empty;Check(v.SetMasterVolumeLevelScalar(Math.Max(0,Math.Min(1,f)),ref g));return 0;});}
 public static void Mute(string id,bool m){With(id,delegate(IVolume v){var g=Guid.Empty;Check(v.SetMute(m,ref g));return 0;});}
 public static void SetDefault(string id){object obj=new Policy();try{var p=(IPolicy)obj;for(int role=0;role<3;role++)Check(p.SetDefaultEndpoint(id,role));}finally{Release(obj);}}
 public static bool CanSwitch(){object obj=new Policy();try{return obj is IPolicy;}finally{Release(obj);}}
 static void Release(object obj){if(obj!=null&&Marshal.IsComObject(obj))Marshal.ReleaseComObject(obj);}
 [DllImport("ole32.dll",EntryPoint="PropVariantClear")]static extern int Clear(ref Prop p);
 [StructLayout(LayoutKind.Sequential)]public struct Key{public Guid fmtid;public uint pid;}
 [StructLayout(LayoutKind.Explicit,Size=24)]public struct Prop{[FieldOffset(0)]public ushort vt;[FieldOffset(8)]public IntPtr ptr;}
 [ComImport,Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]class MMEnum{}
 [ComImport,Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IEnum {
 [PreserveSig]int EnumAudioEndpoints(int flow,uint state,out ICollection col);
 [PreserveSig]int GetDefaultAudioEndpoint(int flow,int role,out IDevice device);
 [PreserveSig]int GetDevice([MarshalAs(UnmanagedType.LPWStr)]string id,out IDevice device);
 [PreserveSig]int RegisterEndpointNotificationCallback(IntPtr p);
 [PreserveSig]int UnregisterEndpointNotificationCallback(IntPtr p);
 }
 [ComImport,Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface ICollection{[PreserveSig]int GetCount(out uint count);[PreserveSig]int Item(uint index,out IDevice d);}
 [ComImport,Guid("D666063F-1587-4E43-81F1-B948E807363F"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IDevice {
 [PreserveSig]int Activate(ref Guid iid,int context,IntPtr param,[MarshalAs(UnmanagedType.IUnknown)]out object obj);
 [PreserveSig]int OpenPropertyStore(int access,out IStore store);
 [PreserveSig]int GetId([MarshalAs(UnmanagedType.LPWStr)]out string id);
 [PreserveSig]int GetState(out uint state);
 }
 [ComImport,Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IStore {
 [PreserveSig]int GetCount(out uint n);[PreserveSig]int GetAt(uint i,out Key key);[PreserveSig]int GetValue(ref Key key,out Prop value);
 [PreserveSig]int SetValue(ref Key key,ref Prop value);[PreserveSig]int Commit();
 }
 [ComImport,Guid("5CDF2C82-841E-4546-9722-0CF74078229A"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]public interface IVolume {
 [PreserveSig]int RegisterControlChangeNotify(IntPtr n);[PreserveSig]int UnregisterControlChangeNotify(IntPtr n);[PreserveSig]int GetChannelCount(out uint n);
 [PreserveSig]int SetMasterVolumeLevel(float f,ref Guid g);[PreserveSig]int SetMasterVolumeLevelScalar(float f,ref Guid g);
 [PreserveSig]int GetMasterVolumeLevel(out float f);[PreserveSig]int GetMasterVolumeLevelScalar(out float f);
 [PreserveSig]int SetChannelVolumeLevel(uint n,float f,ref Guid g);[PreserveSig]int SetChannelVolumeLevelScalar(uint n,float f,ref Guid g);
 [PreserveSig]int GetChannelVolumeLevel(uint n,out float f);[PreserveSig]int GetChannelVolumeLevelScalar(uint n,out float f);
 [PreserveSig]int SetMute([MarshalAs(UnmanagedType.Bool)]bool m,ref Guid g);[PreserveSig]int GetMute([MarshalAs(UnmanagedType.Bool)]out bool m);
 [PreserveSig]int GetVolumeStepInfo(out uint a,out uint b);[PreserveSig]int VolumeStepUp(ref Guid g);[PreserveSig]int VolumeStepDown(ref Guid g);
 [PreserveSig]int QueryHardwareSupport(out uint n);[PreserveSig]int GetVolumeRange(out float min,out float max,out float inc);
 }
 [ComImport,Guid("870AF99C-171D-4F9E-AF0D-E63DF40C2BC9")]class Policy{}
 [ComImport,Guid("F8679F50-850A-41CF-9C72-430F290290C8"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IPolicy {
 [PreserveSig]int GetMixFormat(IntPtr a,IntPtr b);[PreserveSig]int GetDeviceFormat(IntPtr a,int b,IntPtr c);
 [PreserveSig]int ResetDeviceFormat(IntPtr a);[PreserveSig]int SetDeviceFormat(IntPtr a,IntPtr b,IntPtr c);
 [PreserveSig]int GetProcessingPeriod(IntPtr a,int b,IntPtr c,IntPtr d);[PreserveSig]int SetProcessingPeriod(IntPtr a,IntPtr b);
 [PreserveSig]int GetShareMode(IntPtr a,IntPtr b);[PreserveSig]int SetShareMode(IntPtr a,IntPtr b);
 [PreserveSig]int GetPropertyValue(IntPtr a,IntPtr b,IntPtr c);[PreserveSig]int SetPropertyValue(IntPtr a,IntPtr b,IntPtr c);
 [PreserveSig]int SetDefaultEndpoint([MarshalAs(UnmanagedType.LPWStr)]string id,int role);
 [PreserveSig]int SetEndpointVisibility([MarshalAs(UnmanagedType.LPWStr)]string id,int visible);
 }
}
}
