const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('orbit', {
 call: (method, args={}) => ipcRenderer.invoke('call', method, args),
 send: (type, data) => ipcRenderer.send('event', type, data),
 on: fn => { ipcRenderer.on('state',(_,data)=>fn(data)); }
});
